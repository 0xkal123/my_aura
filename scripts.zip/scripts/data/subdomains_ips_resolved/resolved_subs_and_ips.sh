#!/bin/bash

# Check for company name input
if [ -z "$1" ]; then
    echo "Usage: $0 <company name>"
    exit 1
fi

COMPANY=$1
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
OUTPUT_DIR="/root/Desktop/BB/recon/$COMPANY/data/subdomains_ips_resolved"
FINAL_SUBDOMAINS="$BASE_DIR/data/subdomains/final_subdomains.txt"
FINAL_IPS="$BASE_DIR/data/ips/final_ips.txt"

mkdir -p "$OUTPUT_DIR"

# -----------------------
#  Resolving Subdomains
# -----------------------
echo -e "\n[*] Resolving subdomains using dnsx (A, AAAA, and CNAME records)..."
# A record
cat "$FINAL_SUBDOMAINS" | dnsx -a -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 > "$OUTPUT_DIR/a.txt"
# AAAA record
cat "$FINAL_SUBDOMAINS" | dnsx -aaaa -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 > "$OUTPUT_DIR/aaaa.txt"
# CNAME record
cat "$FINAL_SUBDOMAINS" | dnsx -cname -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 > "$OUTPUT_DIR/cname.txt"

# Merge & sort
cat "$OUTPUT_DIR/"{a,aaaa,cname}.txt | sort -u > "$OUTPUT_DIR/resolved_subdomains.txt"

echo "[✔] Resolving subdomains completed."
echo "[-] Total resolved subdomains: $(wc -l < "$OUTPUT_DIR/resolved_subdomains.txt")"
sleep 1


# -----------------------
#  Resolving IPs
# -----------------------
# echo -e "\n[*] Resolving IPs using dnsx..."
# cat "$FINAL_IPS" | dnsx -ptr -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 | sort -u > "$OUTPUT_DIR/resolved_ips.txt"
# echo "[✔] Resolving IPs completed."
# echo "[-] Total resolved IPs: $(wc -l < "$OUTPUT_DIR/resolved_ips.txt")"
# sleep 1
