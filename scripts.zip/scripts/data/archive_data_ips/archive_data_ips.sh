#!/bin/bash

# =============================
# 🔹 ARCHIVE DATA FOR EACH IP
# =============================

if [ $# -ne 1 ]; then
    echo "Usage: $0 <company_name>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"

HTTPX_FINAL_IPS_PLAIN_FILE="$BASE_DIR/data/ips_organized/httpx_final_ips_plain.txt"

if [ ! -d "$BASE_DIR" ]; then
    echo "No base directory found for: $COMPANY"
    exit 1
fi

# -----------------------
# 🔹 PROCESS EACH IP
# -----------------------

exec 3< <(grep -v ':' "$HTTPX_FINAL_IPS_PLAIN_FILE")

while IFS= read -r ip <&3; do
    echo -e "\n[+] Starting Archive Collection for: $ip"

    DOMAIN_DIR="$BASE_DIR/data/archive_data_ips/$ip"
    mkdir -p "$DOMAIN_DIR"

    # ╭─────────────────────╮
    # |     WAYBACKURLS     |
    # ╰─────────────────────╯
    echo "[•] Running Waybackurls for $ip ..."
    echo "$ip" | waybackurls | egrep -v "^[[:blank:]]*$" | anew -q "$DOMAIN_DIR/${ip}_waybackurls.txt"
    echo "[✓] Waybackurls for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_waybackurls.txt") urls"
    echo ""

    # ╭─────────────────────╮
    # |        GAU          |
    # ╰─────────────────────╯
    echo "[•] Running GAU for $ip ..."
    echo "${ip}" | gau --providers commoncrawl,otx,urlscan --config /root/.gau.toml --retries 2 --threads 5 --timeout 10 | anew -q "$DOMAIN_DIR/${ip}_gau.txt"
    echo "[✓] GAU for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_gau.txt") urls"
    echo ""
        
    # ╭─────────────────────╮
    # |       hakrawler     |
    # ╰─────────────────────╯
    echo "[•] Running Hakrawler for $ip ..."
    echo "https://${ip}" | hakrawler -d 0 -insecure -t 25 -timeout 15 | anew -q "$DOMAIN_DIR/${ip}_hakrawler.txt"
    echo "[✓] Hakrawler for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_hakrawler.txt") urls"
    echo ""
    
    # ╭─────────────────────╮
    # |      GOSPIDER       |
    # ╰─────────────────────╯
    echo "[•] Running Gospider for $ip ..."
    gospider -s "https://${ip}" --user-agent "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36" --quiet --depth 5 --delay 1 --threads 80 --random-delay 1 --timeout 10 --js --robots --other-source --include-other-source --sitemap --no-redirect --raw | anew -q "$DOMAIN_DIR/${ip}_gospider.txt"
    echo "[✓] Gospider for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_gospider.txt") urls"
    echo ""
    
    # ╭─────────────────────╮
    # |     URLGRAB         |
    # ╰─────────────────────╯
    echo "[•] Running urlgrab for $ip ..."
    urlgrab -url "https://$ip" -depth 9 -threads 80 -timeout 10 -js-timeout 10 -ignore-ssl -random-agent -delay 1000 | egrep -v "^[[:blank:]]*$" | anew -q "$DOMAIN_DIR/${ip}_urlgrab.txt"
    echo "[✓] urlgrab for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_urlgrab.txt") urls"
    echo ""
    
    # ╭─────────────────────╮
    # | KATANA ACTIVE df    |
    # ╰─────────────────────╯
    echo "[•] Running Katana Active DF for $ip ..."
    echo "${ip}" | katana -d 9 -jc -jsl -xhr -aff -fx -s depth-first -ct 2m -c 20 -rl 10 -silent | anew -q "$DOMAIN_DIR/${ip}_katana_df.txt"
    echo "[✓] Katana Active DF for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_katana_df.txt") urls"
    echo ""

    # ╭─────────────────────╮
    # | KATANA ACTIVE bf    |
    # ╰─────────────────────╯
    echo "[•] Running Katana Active BF for $ip ..."
    echo "${ip}" | katana -d 9 -jc -jsl -xhr -aff -fx -s breadth-first -ct 2m -c 20 -rl 10 -silent | anew -q "$DOMAIN_DIR/${ip}_katana_bf.txt"
    echo "[✓] Katana Active BF for $ip found $(wc -l < "$DOMAIN_DIR/${ip}_katana_bf.txt") urls"
    echo ""

    echo -e "[•] Building pre_all_archive and merging JS endpoints for: $ip"

    # --- 1) Build pre_all_archive: keep ONLY exact host == IP
    cat "$DOMAIN_DIR"/*.txt \
      | awk -v d="$ip" 'BEGIN{IGNORECASE=1}
          $0 ~ /^https?:\/\// {split($0,a,"/"); if (a[3]==d) print $0}' \
      | sort -u > "$DOMAIN_DIR/pre_all_archive.txt"

    # --- 2) From pre_all, pick JS refs, verify live JS, extract same-host endpoints
    JS_URLS="$DOMAIN_DIR/js_urls.txt"
    JS_WORKING="$DOMAIN_DIR/js_urls_working.txt"
    JS_ENDPOINTS="$DOMAIN_DIR/js_endpoints.txt"

    grep -Ei '\.js($|\?)' "$DOMAIN_DIR/pre_all_archive.txt" | sort -u > "$JS_URLS"

    if [ -s "$JS_URLS" ]; then
      httpx -silent -nc -threads 6 -rate-limit 5 -timeout 10 -mc 200 -ct -l "$JS_URLS" \
        | grep -E "application/javascript|application/x-javascript|application/ecmascript|application/x-ecmascript|application/json|application/x-json|application/octet-stream|text/javascript|text/x-javascript|text/ecmascript|text/x-ecmascript|text/plain|x-text/plain" \
        | awk '{print $1}' > "$JS_WORKING"
    else
      : > "$JS_WORKING"
    fi

    # --- Write all_archive.txt from pre_all with image/font filter
    grep -vEi '\.(png|jpg|jpeg|jpe|jif|jfif|jfi|gif|bmp|dib|tif|tiff|svg|svgz|webp|ico|cur|psd|ai|eps|heif|heic|jp2|j2k|jpf|jpm|jpx|apng|avif|raw|cr2|nef|nrw|orf|raf|rw2|sr2|srf|arw|dng|pef|ptx|x3f|ttf|otf|css)(\?|$|&)' \
      "$DOMAIN_DIR/pre_all_archive.txt" \
      | sort -u > "$DOMAIN_DIR/all_archive.txt"

    : > "$JS_ENDPOINTS"   # reset js_endpoints file
    if [ -s "$JS_WORKING" ]; then
      while read -r jsu; do
        [ -z "$jsu" ] && continue
        host="$(echo "$jsu" | awk -F/ '{print $3}')"
        python3 ~/Desktop/tools/LinkFinder/linkfinder.py -i "$jsu" -o cli 2>/dev/null \
          | grep -viE '\.jpg|\.png|\.svg|w3\.org' \
          | while read -r ep; do
              [ -z "$ep" ] && continue
              if [[ "$ep" =~ ^https?:// ]]; then
                ephost="$(echo "$ep" | awk -F/ '{print $3}')"
                [ "$ephost" = "$host" ] && echo "$ep" | grep -v "text/" | grep -v "application/"
              else
                echo "$host/${ep#/}" | grep -v "text/" | grep -v "application/"
              fi
            done
      done < "$JS_WORKING" \
        | sort -u >> "$JS_ENDPOINTS"
    fi

    # dedupe js_endpoints + filter images before merging
    if [ -s "$JS_ENDPOINTS" ]; then
      sort -u "$JS_ENDPOINTS" \
        | grep -vEi '\.(png|jpg|jpeg|jpe|jif|jfif|jfi|gif|bmp|dib|tif|tiff|svg|svgz|webp|ico|cur|psd|ai|eps|heif|heic|jp2|j2k|jpf|jpm|jpx|apng|avif|raw|cr2|nef|nrw|orf|raf|rw2|sr2|srf|arw|dng|pef|ptx|x3f|ttf|otf|css)(\?|$|&)' \
        | anew -q "$DOMAIN_DIR/all_archive.txt"
    fi

    total_domain_urls=$(wc -l < "$DOMAIN_DIR/all_archive.txt")
    total_js_urls=$(wc -l < "$JS_ENDPOINTS")
    echo "[📊] Total URLs found for $ip: $total_domain_urls (JS endpoints: $total_js_urls)"
    echo ""
    
    # ------------------------
    # 🔹 CLEANUP INTERMEDIATE FILES (remove only after all_archive.txt exists)
    # ------------------------
    if [ -s "$DOMAIN_DIR/all_archive.txt" ]; then
        echo "[•] Cleaning up intermediate files for $domain ..."
        # list and delete only the patterns you requested
        deleted_files_count=0
        # Use find to print then delete; count lines printed
        deleted_list=$(find "$DOMAIN_DIR" -type f \( \
            -iname 'pre_all_archive.txt' -o \
            -iname 'js_urls.txt' -o \
            -iname '*_crawley.txt' -o \
            -iname '*_gau.txt' -o \
            -iname '*_github-endpoints.txt' -o \
            -iname '*_gospider.txt' -o \
            -iname '*_hakrawler.txt' -o \
            -iname '*_katana_bf.txt' -o \
            -iname '*_katana_df.txt' -o \
            -iname '*_urlgrab.txt' -o \
            -iname '*_waybackurls.txt' \
        \) -print)

        if [ -n "$deleted_list" ]; then
            # show what will be removed
            echo "$deleted_list"
            # delete them
            find "$DOMAIN_DIR" -type f \( \
                -iname 'pre_all_archive.txt' -o \
                -iname 'js_urls.txt' -o \
                -iname '*_crawley.txt' -o \
                -iname '*_gau.txt' -o \
                -iname '*_github-endpoints.txt' -o \
                -iname '*_gospider.txt' -o \
                -iname '*_hakrawler.txt' -o \
                -iname '*_katana_bf.txt' -o \
                -iname '*_katana_df.txt' -o \
                -iname '*_urlgrab.txt' -o \
                -iname '*_waybackurls.txt' \
            \) -exec rm -f {} +

            deleted_files_count=$(echo "$deleted_list" | wc -l)
            echo "[✓] Removed $deleted_files_count intermediate files for $domain"
        else
            echo "[•] No intermediate files to remove for $domain"
        fi
    else
        echo "[!] all_archive.txt not present or empty for $domain — skipping cleanup."
    fi
    
done

exec 3<&-

# ------------------------
#  FINAL ARCHIVE CONSOLIDATION
# ------------------------

mkdir -p "$BASE_DIR/data/archive_data_ips"   # <-- ADD THIS LINE

echo "[•] Consolidating ALL all_archive.txt files in data/archive_data_ips/ ..."
find "$BASE_DIR/data/archive_data_ips/" -type f -name "all_archive.txt" -exec cat {} + | sort -u > "$BASE_DIR/data/archive_data_ips/final_all_archive.txt"
echo "[✔] final_all_archive.txt created at: $BASE_DIR/data/archive_data_ips/final_all_archive.txt with $(wc -l < "$BASE_DIR/data/archive_data_ips/final_all_archive.txt") urls"

echo "[•] Consolidating ALL js_endpoints.txt files in data/archive_data_ips/ ..."
find "$BASE_DIR/data/archive_data_ips/" -type f -name "js_endpoints.txt" -exec cat {} + | sort -u > "$BASE_DIR/data/archive_data_ips/final_js_endpoints.txt"
echo "[✔] final_js_endpoints.txt created at: $BASE_DIR/data/archive_data_ips/final_js_endpoints.txt with $(wc -l < "$BASE_DIR/data/archive_data_ips/final_js_endpoints.txt") urls"
