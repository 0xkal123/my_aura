#!/bin/bash

# ------------------------
# 🔹 INPUT VALIDATION
# ------------------------
if [ $# -ne 1 ]; then
    echo "Usage: $0 <company_name>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
FINAL_ALL_ARCHIVE="/root/Desktop/BB/recon/$COMPANY/data/archive_data_subs/final_all_archive.txt"
OUTPUT_BASE="/root/Desktop/BB/recon/$COMPANY/data/archive_filtered_subs"
API="$OUTPUT_BASE/api"
DASHBOARDS_PANELS="$OUTPUT_BASE/dashboards-panels"
CLOUD="$OUTPUT_BASE/cloud"
IDENTIFIERS="$OUTPUT_BASE/identifiers"
UNSUBSCRIBE="$OUTPUT_BASE/unsubscribe"
FILES="$OUTPUT_BASE/files"
ENDPOINTS="$OUTPUT_BASE/endpoints"
SECRETS="$OUTPUT_BASE/secrets"

# Check if FINAL_ALL_ARCHIVE exists
if [ ! -f "$FINAL_ALL_ARCHIVE" ]; then
    echo "[!] Input file missing, creating empty file: $FINAL_ALL_ARCHIVE"
    mkdir -p "$(dirname "$FINAL_ALL_ARCHIVE")"
    touch "$FINAL_ALL_ARCHIVE"
fi


# Create all output directories
mkdir -p "$OUTPUT_BASE/ext_fuzz_urls" "$OUTPUT_BASE/injection_params" "$API" "$DASHBOARDS_PANELS" "$CLOUD" "$IDENTIFIERS" "$UNSUBSCRIBE" "$FILES" "$ENDPOINTS" "$SECRETS"

#ext_fuzz_urls
grep -iE "\.aspx"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/aspx.txt"
grep -iE "\.ashx"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/ashx.txt"
grep -iE "\.asmx"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/asmx.txt"
grep -iE "\.asp"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/asp.txt"
grep -iE "\.axd"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/axd.txt"
grep -iE "\.php"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/php.txt"
grep -iE "\.php3"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/php3.txt"
grep -iE "\.php4"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/php4.txt"
grep -iE "\.php5"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/php5.txt"
grep -iE "\.php7"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/php7.txt"
grep -iE "\.php8"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/php8.txt"
grep -iE "\.phtml"  $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/phtml.txt"
grep -iE "\.jsp"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/jsp.txt"
grep -iE "\.jspx"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/jspx.txt"
grep -iE "\.jsf"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/jsf.txt"
grep -iE "\.jspa"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/jspa.txt"
grep -iE "\.do"     $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/do.txt"
grep -iE "\.action" $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/action.txt"
grep -iE "\.xhtml"  $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/xhtml.txt"
grep -iE "\.cfm"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/cfm.txt"
grep -iE "\.cfml"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/cfml.txt"
grep -iE "\.py"     $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/py.txt"
grep -iE "\.pyc"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/pyc.txt"
grep -iE "\.rb"     $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/rb.txt"
grep -iE "\.rhtml"  $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/rhtml.txt"
grep -iE "\.erb"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/erb.txt"
grep -iE "\.rjs"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/rjs.txt"
grep -iE "\.pl"     $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/pl.txt"
grep -iE "\.perl"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/perl.txt"
grep -iE "\.cgi"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/cgi.txt"
grep -iE "\.cgi-bin" $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/cgi-bin.txt"
grep -iE "\.svc"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/svc.txt"
grep -iE "\.wsdl"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/wsdl.txt"
grep -iE "\.ssjs"   $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/ssjs.txt"
grep -iE "\.ejs"    $FINAL_ALL_ARCHIVE > "$OUTPUT_BASE/ext_fuzz_urls/ejs.txt"

# ==================

# Injection params
# --- MINIMAL SAFETY FIX: treat gf outputs as files of literal strings, avoid grep -f interpreting [] or - as regex ---
cat $FINAL_ALL_ARCHIVE | gf lfi | sort -u > "$OUTPUT_BASE/injection_params/lfi_params.txt"
cat $FINAL_ALL_ARCHIVE | gf sqli | sort -u > "$OUTPUT_BASE/injection_params/sqli_params.txt"
cat $FINAL_ALL_ARCHIVE | gf or | sort -u > "$OUTPUT_BASE/injection_params/or_params.txt"
cat $FINAL_ALL_ARCHIVE | gf ssrf | sort -u > "$OUTPUT_BASE/injection_params/ssrf_params.txt"
cat $FINAL_ALL_ARCHIVE | gf ssti | sort -u > "$OUTPUT_BASE/injection_params/ssti_params.txt"
cat $FINAL_ALL_ARCHIVE | gf rce | sort -u > "$OUTPUT_BASE/injection_params/rce_params.txt"
cat $FINAL_ALL_ARCHIVE | gf cmdi | sort -u > "$OUTPUT_BASE/injection_params/cmdi_params.txt"
cat $FINAL_ALL_ARCHIVE | gf idor | sort -u > "$OUTPUT_BASE/injection_params/idor_params.txt"

# --- Simplified replacement ---
tmp_inj=$(mktemp)
cat "$OUTPUT_BASE"/injection_params/*.txt > "$tmp_inj"
sed -i '/^$/d' "$tmp_inj"

grep "=" "$FINAL_ALL_ARCHIVE" | grep -v "$tmp_inj" > "$OUTPUT_BASE/Params_without_gf_patterns.txt"

rm -f "$tmp_inj"

# =======================

# URLs with extensions
grep -E '[^/]+/[^ ]*\.[^/ ?#]+' "$FINAL_ALL_ARCHIVE" | grep -vEi '\.(png|jpg|jpeg|jpe|jif|jfif|jfi|gif|bmp|dib|tif|tiff|svg|svgz|webp|ico|cur|psd|ai|eps|heif|heic|jp2|j2k|jpf|jpm|jpx|apng|avif|raw|cr2|nef|nrw|orf|raf|rw2|sr2|srf|arw|dng|pef|ptx|x3f|js)(\?|$)' > "$OUTPUT_BASE/Urls_with_extensions.txt"

# URLs without extensions
grep -E '[^/]+/([^.?&#/]+([/?#].*)?|$)' "$FINAL_ALL_ARCHIVE" > "$OUTPUT_BASE/Urls_without_extensions.txt"

# =======================

# api
grep -iE "([a-zA-Z0-9_./-]*)api([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/api_generic.txt"
grep -iE "([a-zA-Z0-9_./-]*)api/v[0-9]+/([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/api_versioned.txt"
grep -iE "([a-zA-Z0-9_./-]*)v[0-9]+/([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/api_v1-9_urls.txt"
grep -iE "([a-zA-Z0-9_./-]*)(graphql|gql)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/graphql_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)(rest)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/rest_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)(swagger(-ui|_ui)?|swagger-resources|swagger-docs?|swagger-config|swagger-editor|swagger-initializer|api-docs?|openapi)(\.json|\.yaml|\.html)?([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/swagger_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)actuator([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/actuator_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)(explorer|apispec|rpc|odata|edge|rest|api|endpoint)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/misc_api_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)(swagger|openapi|graphql|gql|rest|actuator|explorer|apispec|rpc|odata|edge|api-docs?|v[0-9]+)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$API/all_api_endpoints.txt"

# Dashboards-Panels
grep -iE "([a-zA-Z0-9_./-]*)(kibana|grafana|jenkins|jira|confluence|atlassian|okta|corp|sonar|splunk|prometheus|sonarqube|portainer|rundeck|cacti|zabbix|elastic|elasticsearch|newrelic|datadog|nagios|zookeeper|consul|vault|spring|springfox|fastapi|redoc|script|/securityRealm/login|manage|user/admin|django|flask)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$DASHBOARDS_PANELS/third_party_dashboards.txt"
grep -iE "(user-admin|useradmin|userpanel|admin|user-management|user_manage|account_manage|role_manage|permissions_manage|access-control|accesscontrol|privilege_manage)" $FINAL_ALL_ARCHIVE > "$DASHBOARDS_PANELS/user_management_panels.txt"
grep -iE "(admin/login|admin\.php|admin_panel|admin|admin-panel|adminpanel|dashboard|dash_board|dash-board|console|cpanel|c-panel|c_panel|manage|manager|superadmin|super_admin|super-admin|internal|sysadmin|sys_admin|sys-admin|private|backend|back_end|back-end|private|staff|employee|moderator|secure/admin|api/admin|internal/dashboard|user/manage|user/privilege|access_control|access-control|accesscontrol|permissions|roles|privileges|devtools|dev-tools|dev_tools|debug|logger|logviewer|log_viewer|log-viewer|systeminfo|system_info|system-info|phpinfo|php_info|php-info|troubleshoot|trouble-shoot|trouble_shoot|\.env\.local|phpinfo\.php|info\.php|portallogin|api|admin|staging|beta|dev|blog|mail|forum|support|upload|portal|payments|cdn|partners|test|shop|assets|docs|demo|beta-api|git|monitoring|internal|blog2|staging-api|vpn|api-v2|beta-admin|crm|intranet|app|jobs|lab|partners-api|internal-api|mobile|cms|auth|chat|cdn2|logs|help|demo-api|bugs|downloads|dashboard|developer|enterprise|grafana|jira|map|maps|rabbitmq|subscription|engineering|admiral|feedback|reward|weblogin|signup|register|zendesk|usuarios|moderator|adm|controlpanel|affiliate|admin|jenkins|test|proxy|stage|dev|devops|staff|db|qa|internal)" $FINAL_ALL_ARCHIVE > "$DASHBOARDS_PANELS/panels_endpoints.txt"
grep -iE "(stripe_invoice_id|stripe-invoice-id|paypal_invoice_id|paypal-invoice-id|xero_invoice_id|xero-invoice-id|quickbooks_invoice_id|quickbooks-invoice-id|paypal_email|paypal-email|paypalemail|paypal-id|paypal_id|paypalid)" $FINAL_ALL_ARCHIVE > "$DASHBOARDS_PANELS/third_party-sensitive.txt"

# Cloud
grep -iE "([a-zA-Z0-9_./-]*)(gitlab|bitbucket|circleci|travis|github-actions)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$CLOUD/ci_cd_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)(rabbitmq|kafka|etcd|mongo|postgres|mysql|redis|cassandra)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$CLOUD/misc_db_endpoints.txt"
grep -iE "([a-zA-Z0-9_./-]*)(s3\.amazonaws\.com|\.s3\.amazonaws\.com|blob\.core\.windows\.net|storage\.googleapis\.com|\.firebaseio\.com|f000\.backblazeb2\.com)([a-zA-Z0-9_./?=&-]*)?" $FINAL_ALL_ARCHIVE > "$CLOUD/cloud_storage_endpoints.txt"
grep -iE "s3\.amazonaws\.com|storage\.googleapis\.com|digitaloceanspaces\.com|wasabisys\.com|blob\.core\.windows\.net|linodeobjects\.com|cloudfront\.net" $FINAL_ALL_ARCHIVE > "$CLOUD/cloud_storage_urls.txt"

# Secrets
grep -iE "(AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|A3T[A-Z0-9]{13}|ACCA[A-Z0-9]{12}|AGPA[A-Z0-9]{12}|AIDA[A-Z0-9]{12}|ANPA[A-Z0-9]{12}|ANVA[A-Z0-9]{12}|AROA[A-Z0-9]{12}|s3://|bucket|aws_access_key_id|aws_access_key|aws_secret_key|AKIA|ASIA|aws_secret_access_key|amazonaws)" $FINAL_ALL_ARCHIVE > "$SECRETS/aws-secrets.txt"
grep -iE "(AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AMAZON_AWS_ACCESS_KEY_ID|AMAZON_AWS_SECRET_ACCESS_KEY|ALGOLIA_API_KEY|AZURE_CLIENT_ID|AZURE_CLIENT_SECRET|AZURE_USERNAME|AZURE_PASSWORD|MSI_ENDPOINT|MSI_SECRET|binance_api|binance_secret|BITTREX_API_KEY|BITTREX_API_SECRET|CF_PASSWORD|CF_USERNAME|CODECLIMATE_REPO_TOKEN|COVERALLS_REPO_TOKEN|CIRCLE_TOKEN|DIGITALOCEAN_ACCESS_TOKEN|DOCKER_EMAIL|DOCKER_PASSWORD|DOCKER_USERNAME|DOCKERHUB_PASSWORD|FACEBOOK_APP_ID|FACEBOOK_APP_SECRET|FACEBOOK_ACCESS_TOKEN|FIREBASE_TOKEN|FIREBASE_API_TOKEN|FOSSA_API_KEY|GH_TOKEN|GH_ENTERPRISE_TOKEN|CI_DEPLOY_PASSWORD|CI_DEPLOY_USER|GOOGLE_APPLICATION_CREDENTIALS|GOOGLE_API_KEY|GITLAB_USER_LOGIN|CI_JOB_JWT|CI_JOB_JWT_V2|CI_JOB_TOKEN|HEROKU_API_KEY|HEROKU_API_USER|MAILGUN_API_KEY|MCLI_PRIVATE_API_KEY|MCLI_PUBLIC_API_KEY|NGROK_TOKEN|NGROK_AUTH_TOKEN|NPM_AUTH_TOKEN|SLACK_API_TOKEN|OKTA_CLIENT_ORGURL|OKTA_CLIENT_TOKEN|OKTA_OAUTH2_CLIENTSECRET|OKTA_OAUTH2_CLIENTID|OKTA_AUTHN_GROUPID|OS_USERNAME|OS_PASSWORD|PERCY_TOKEN|POSTGRES_PASSWORD|SMTP_PASSWORD|SAUCE_ACCESS_KEY|SAUCE_USERNAME|SENTRY_AUTH_TOKEN|SLACK_TOKEN|square_access_token|square_oauth_secret|STRIPE_API_KEY|STRIPE_DEVICE_NAME|SURGE_TOKEN|SURGE_LOGIN|TWILIO_ACCOUNT_SID|CONSUMER_KEY|CONSUMER_SECRET|TRAVIS_SUDO|TRAVIS_OS_NAME|TRAVIS_SECURE_ENV_VARS|TELEGRAM_BOT_TOKEN|VAULT_TOKEN|VAULT_CLIENT_KEY|TOKEN|VULTR_ACCESS|VULTR_SECRET|ConsumerKey|ConsumerSecret|DB_USERNAME|HEROKU_API_KEY|HOMEBREW_GITHUB_API_TOKEN|JEKYLL_GITHUB_TOKEN|PT_TOKEN|SESSION_TOKEN|SF_USERNAME|SLACK_BOT_TOKEN|DOCKER_AUTH_CONFIG|JENKINS_API_TOKEN|PAYPAL_LIVE_API_USERNAME|STRIPE_SECRET_KEY|MONGO_INITDB_ROOT_PASSWORD|FIREBASE_API_KEY|access_token_secret|api-key|api_key|apikey|api_secret_key|api-secret-key|apisecretkey|api_token|auth_token|authkey|authorization|authorization_key|authorization_token|authtoken|aws_access_key_id|bearer|bot_access_token|bucket|client-secret|client_secret|clientsecret|consumer_key|consumer-key|consumerkey|consumer_secret|consumer-secret|consumersecret|dbpasswd|db-passwd|db_passwd|email|encryption-key|encryption_key|encryptionkey|id_dsa|irc_pass|oauth_token|password|private_key|private-key|privatekey|secret-key|secret_key|secret_token|secretkey|session_key|session_secret|slack_api_token|slack_secret_token|slack_token|ssh-key|ssh_key|sshkey|phrase|hash|username|xoxa-2|xoxr|key|token|code|ban|secret|salt|pass|code|private|auth_token|auth-token|authtoken|authid|auth_id|auth-id|authsession|auth-session|auth_session|loginsession|login-session|login_session|authorization|authorisation|jwt|sessionid|session-id|session_id|access_token|access-token|accesstoken|CertnetId)" $FINAL_ALL_ARCHIVE > "$SECRETS/apikeys-secrets.txt"

# Identifiers
grep -iE "(role|invite|company|organization|org_id|orgid|org-id|org_name|orgname|org-name|tenant_id|tenantid|tenant-id|account_id|accountid|account-id|workspace_id|workspaceid|workspace-id|project|project_id|projectid|project-id|team|team_id|teamid|team-id|member_id|memberid|member-id|employee|employee_id|employeeid|employee-id|customer_id|customerid|customer-id|vendor_id|vendorid|vendor-id|vendor|partner_id|partnerid|partner-id|partner|group_id|groupid|group-id|group)" $FINAL_ALL_ARCHIVE > "$IDENTIFIERS/invite-link_params.txt"
grep -iE "(user_id|userid|user-id|accountid|account_id|account-id|accountnumber|account-number|account_number|customer_id|customerid|customer-id|custid|cust_id|cust-id|memberid|member-id|member_id|mid|m-id|m_id|profileid|profile-id|profile_id|email|username|client_id|clientid|client-id|visitid|visit-id|visit_id|visit|staff_id|staff-id|staffid)" $FINAL_ALL_ARCHIVE > "$IDENTIFIERS/IDENTIFIERS.txt"
grep -iE "(fileid|file-id|file_id|documentid|document-id|document_id|docid|doc-id|doc_id|attachmentid|attachment-id|attachment_id|mediaid|media-id|privateid|private_id|private-id|media_id|resourceid|resource-id|resource_id|uploadid|upload-id|upload_id|imageid|image-id|image_id|photoid|photo-id|photo_id|avatarid|avatar-id|avatar_id|contentid|content-id|content_id|filename|file-name|file_name|filepath|file-path|file_path|documentkey|document-key|document_key|uploadkey|upload-key|upload_key|hold_key|hold-key|holdkey|moderatorid|moderator-id|moderator_id)" $FINAL_ALL_ARCHIVE > "$IDENTIFIERS/file-identifiers.txt"
cat $FINAL_ALL_ARCHIVE | unfurl --unique format %u > "$IDENTIFIERS/user_info.txt"
 
# Unsubscribe IDOR
grep -iE "(email.*unsubscribe|unsubscribe.*email|newsletter.*unsubscribe|unsubscribe.*newsletter|email.*opt[-_ ]?out|opt[-_ ]?out.*email)" $FINAL_ALL_ARCHIVE > "$UNSUBSCRIBE/unsubscribe_endpoints.txt"

# files
grep -iE "\.png|\.jpg|\.jpeg|\.gif|\.bmp|\.tiff|\.svg|\.ico|\.webp" $FINAL_ALL_ARCHIVE > "$FILES/image-files.txt"
grep -iE "\.pdf|\.doc|\.docx|\.xls|\.xlsx|\.ppt|\.pptx|\.odt|\.rtf|\.txt|\.csv|\.md" $FINAL_ALL_ARCHIVE > "$FILES/doc-files.txt"
grep -iE "\.sql|\.sqlite|\.db|\.txt|\.accdb|\.dbf|\.psql|sql\.gz|pgsql\.txt|mysql\.txt|\.nsf" $FINAL_ALL_ARCHIVE > "$FILES/database-files.txt"
grep -iE '\.mp4$|\.webm$|\.mkv$|\.avi$|\.mov$|\.flv$|\.wmv$|\.mpeg$|\.mpg$|\.3gp$|\.m4v$' $FINAL_ALL_ARCHIVE > "$FILES/video_urls.txt"
grep -iE '\.mp3$|\.wav$|\.aac$|\.ogg$|\.flac$|\.m4a$|\.wma$|\.amr$' $FINAL_ALL_ARCHIVE > "$FILES/audio_urls.txt"
grep -iE "\.zip|\.tar|\.tar\.gz|\.gz|\.rar|\.7z|\.bz2|tar\.bz2|\.zipx|\.tgz|\.cache|\.cab|\.gzip|\.secret" $FINAL_ALL_ARCHIVE > "$FILES/compressed_archive-files.txt"
grep -iE "\.py|\.java|\.cpp|\.c[^a-z]|\.go|\.rb|\.php|\.jsp|\.asp|\.vb|\.vbs|\.cs|\.pl|\.sh|\.war|\.asmx|\.cfm|\.cnf|\.action|\.adr|\.ascx|\.asc|\.pub|\.axd|\.tpl" $FINAL_ALL_ARCHIVE > "$FILES/source_code-files.txt"
grep -iE "\.env|\.ini|\.yml|\.yaml|\.toml|\.config|\.conf|configs|application\.properties|settings\.py|database\.yml|credentials|web\.config|\.xml|\.dtd|\.properties|\.webproj|\.vbproj|\.ora|\.pac|\.pcf|\.plist|\.rdp|\.reg" $FINAL_ALL_ARCHIVE > "$FILES/configuration-files.txt"
grep -iE "(\.zip\.old$|\.tar\.bz2\.old$|\.sql\.old$|\.tar\.gz\.old$|\.bak1$|\.bak$|\.backup$|\.old$|\.tmp$|\.swp$|\.bkf$|\.bkp$|\.dump$|\.save$|\.save\.1$|\.orig$|\.svn$|_bak$|_old$|backup$|archive$|bkp$|temp$|lock$|dump$|save$|NEW$|bac$|\.bok$|\.achee$|backup_[^/]+\.zip$|backup_[^/]+\.tar$|backup_[^/]+\.sql$|backup_[^/]+\.gz$|backup_[^/]*$|old_[^/]*$|archive_[^/]*$|db_backup_[^/]*$|db_[^/]+\.bak$|db_[^/]+\.backup$|dump_[^/]+$)" $FINAL_ALL_ARCHIVE > "$FILES/backup_filename_patterns.txt"
grep -iE "\.git/|\.svn/|\.hg/|\.bzr/|\.DS_Store|\.idea/|\.vscode/|node_modules/|vendor/|storage/|WEB-INF/|META-INF/" $FINAL_ALL_ARCHIVE > "$FILES/sensitive_dirs.txt"
grep -iE "\.pem|\.key|\.crt|\.cer|\.csr|\.pfx|\.p12" $FINAL_ALL_ARCHIVE > "$FILES/certificate-files.txt"
grep -iE "\.log|\.bash_history" $FINAL_ALL_ARCHIVE > "$FILES/logs-files.txt"
grep -iE "\.exe|\.bin|\.dll|\.sys|\.lnk|\.part|\.iso|\.img|\.rpm|\.sdf|\.pdb|\.deb|\.bat|\.apk|\.msi|\.iso|\.dmg|\.crdownload|\.swf|\.url|\.rdp|\.skr|\.sln|\.mbox|\.mbx|\.pac|\.pcf|\.nsf|\.wml|\.xsd|\.plist|\.inf|\.adr|\.achee|\.cnf|\.mai|\.ora|\.reg|\.tpl|\.pgp|\.inc|\.skr|\.swp|\.dochtml|\.ica|\.atom|\.vcf" $FINAL_ALL_ARCHIVE > "$FILES/miscellaneous.txt"
grep -iE "\.json" $FINAL_ALL_ARCHIVE > "$FILES/json_endpoints.txt"
grep -iE "/server-status|nginx_status|.htaccess|httpd\.conf|apache2\.conf|express/api/v1|flask_app/routes\.py|django/admin|django/settings\.py|laravel/.env|symfony/config|config|root|symfony/.env|jboss-console|weblogic/console|tomcat/manager/html|nginx\.conf|docker-compose\.yml|Procfile|manage\.py|composer\.json|app\.conf|codeception\.yml|docker-compose\.yml|private/api|provision\.awk|once-as-vagrant\.sh|Vagrantfile|flask_app/routes\.py|symfony/config|symfony/.env|jboss-console|.gitignore|.htaccess|vagrant-local\.example\.yml|Vagrantfile|\.git-credentials|\.git|\.npmrc|config\.js|config\.json|settings\.json|database\.json|firebase\.json|/\.env|/\.env\.production|api_keys\.json|credentials\.json|secret\.json|google-services\.json|package\.json|package-lock\.json|composer\.json|pom\.xml|docker-compose\.yml|service-worker\.js|manifest\.json|proxy" $FINAL_ALL_ARCHIVE > "$FILES/server-internal-files.txt"
grep -iE "(firebase\.json$|firebase-messaging-sw\.js$|amplify-config\.json$|appcenter-config\.json$|config\.js$|settings\.js$|env\.js$|environment\.js$|credentials\.json$|google-services\.json$|google\.json$|aws-exports\.js$|awsconfiguration\.json$|aws-exports\.ts$|awsconfiguration\.xml$|runtime-config\.json$|manifest\.json$|onesignal\.sdk\.js$|mixpanel\.config$|segment\.config$|plausible\.config$|analytics\.js$|analytics-config\.json$|airshipconfig\.json$|sentry\.config$|sentry\.properties$)" $FINAL_ALL_ARCHIVE > "$FILES/third_party_configs.txt"
grep -iE "\.circleci/config\.yml|\.github/workflows/|\.gitlab-ci\.yml|Jenkinsfile|\.drone\.yml" $FINAL_ALL_ARCHIVE > "$FILES/cicd_leaks.txt"
grep -iE "(Authorization:\s*Bearer\s+|Bearer\s+[A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+\.[A-Za-z0-9\-_=]+)" $FINAL_ALL_ARCHIVE > "$FILES/auth_jwt_tokens.txt"
grep -iE "(log|logger|internal|phpinfo|debug|trace|exception)" $FINAL_ALL_ARCHIVE > "$FILES/logs-debug_info.txt"
grep -iE "^(ftp|file|ws|wss|gopher|data|irc|telnet|ldap|rtsp|sip|sftp|magnet|news|nntp|smb|svn|git|ssh)://" $FINAL_ALL_ARCHIVE > "$FILES/non_http_urls.txt"
cat $FINAL_ALL_ARCHIVE | grep -E "/\.[^/]+" > "$FILES/dot-prefixed_endpoints.txt"

# Endpoints
grep -iE "(login|signin|signup|register|auth|authentication|authorize|callback|logout|resetpassword|forgotpassword|forgot-password|password-reset|sso|oauth|openid|saml|oidc|oauth2|single-sign-on|identity-provider|idp)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/auth_sso_endpoints.txt"
grep -iE "(activate|confirm|activation_token|activation-token|activationtoken|verification_token|verification-token|verificationtoken|invite_token|invite-token|invitetoken|couponcode|coupon_code|coupon-code|promocode|promo-code|promo_code|register_token|register-token|registertoken|registration_token|registration-token|registrationtoken|confirm_token|confirm-token|confirmtoken|confirmation_token|confirmation-token|confirmationtoken|signup_token|signuptoken|account_activation|account-activation|accountactivation)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/registration_activation-params.txt"
grep -iE "(delete|remove|drop|disable|cut|dismantle|erase|eliminate|discard|clear|destroy|wipe|kill|revoke)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/delete-remove_endpoints.txt"
grep -iE "(passwd|pwd|password|resetpassword|passwordreset|reset-password|reset_password|password-reset|password_reset|confirm_password|confirmpassword|confirm-password)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/password_reset-links.txt"
grep -iE "(verify|email|confirm|activate|validate|email_verify|email-verify|emailverify|verification_token|verification-token|verificationtoken|verify_token|verify-token|verifytoken|verificationcode|verification-code|verification_code|email-verification|email_verification|emailverification|email_address|email-address|emailaddress|download_invoice|download-invoice|downloadinvoice|account/statement|cancelUrl|confirmcode|confirm-code|confirm_code|verify_code|verify-code|verifycode|change_email|change-email|changeemail|resend-email|resendemail|resend_email|password_confirm|password-confirm|passwordconfirm|confirm-account|confirm_account|confirmaccount|validate-email|validateemail|validate_email|validate-email|verify-email|verify_email|verifyemail)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/email-verify.txt"
grep -iE "(birthdate|birth-date|birth_date|tel|fullname|full-name|full_name|first_name|firstname|first-name|email|phone|number|mobile|ssn|passport|aadhar|pan)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/PII_info.txt"
grep -iE "(upload|fileupload|import|export)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/fileupload_urls.txt"
grep -iE "(dev|staging|uat|beta|preprod|test|sandbox|release)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/dev-staging-uat_urls.txt"
grep -iE "(orders|orderid|order-id|order_id|transaction|transactionid|transaction-id|transaction_id|plan_id|plan|plan-id|cartid|cart-id|cart_id|basket_id|basket-id|basketid|loanid|loan-id|loan_id|insurance_id|insuranceid|insurance|insurance-id|premium|claim_id|claimid|claim-id|kyc|payment_reference|payment-reference|payment|paymentreference|product_id|productid|productid|item_id|itemid|item-id|productid|product-id|product_id|itemid|item-id|item_id|sku|invoice|invoice_id|inv_id|invoiceno|invoice_number|inv_no|invoice_no|paystatus|orderref|order_ref|documentid|document_id|docid|receiptid|receipt_id|receipt|billid|bill_id|paymentid|payment_id|total|status|paystatus|pending|base64|signature|billingname|shipname|ship_name|ship-name|address|billingaddress|billing-address|billing_address|shippingaddress|shipping-address|shipping_address|invoicedate|invoice_date|invoicedate|invoice-date|duedate|due_date|viewinvoice|view-invoice|view_invoice|view=invoice|account/statement|payment|payMType|payM_Type|payM-Type|wt\.tx_id|wt\.tx_i|wt\.tx_it|creditcard|credit-card|credit_card|cardholder|card_holder|card-holder|ifsc|swift|cc_number|cc-number|ccnumber|cvv|bank_account|bank-account|bankaccount|payment_token|payment-token|paymenttoken|drivers_license|drivers-license|driverslicense|dl_no|mothers_maiden_name|mothers-maiden-name|subscription)" $FINAL_ALL_ARCHIVE > "$ENDPOINTS/transactions-billing.txt"

# --- MINIMAL SAFETY FIX: avoid process-substitution over many pattern files (prevents /dev/fd/... regex errors and OOM) ---
tmp_patterns=$(mktemp)
dirs=( "$API" "$DASHBOARDS_PANELS" "$CLOUD" "$SECRETS" "$IDENTIFIERS" "$UNSUBSCRIBE" "$FILES" "$ENDPOINTS" )
for d in "${dirs[@]}"; do
  if [ -d "$d" ]; then
    find "$d" -maxdepth 1 -type f -print0 2>/dev/null | xargs -0 -r cat >> "$tmp_patterns"
  fi
done
# remove empty lines and dedupe
sed -i '/^$/d' "$tmp_patterns"
sort -u -o "$tmp_patterns" "$tmp_patterns"

# use fixed-string matching so patterns that contain [] or - won't break grep
grep -v -F -f "$tmp_patterns" "$FINAL_ALL_ARCHIVE" > "$OUTPUT_BASE/Endpoints_Files_with_filters_excluded.txt" || true

rm -f "$tmp_patterns"

# Filtering xml content type subdomains
grep "xml" "$BASE_DIR/data/httpx_subdomains/httpx_final_subs-subs_with_ports_unfiltered.txt" | awk '{print $1}' | sort -u > "$OUTPUT_BASE/xml_data-format_subdomains.txt"
