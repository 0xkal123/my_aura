#!/bin/bash

# ----------------
# INPUT VALIDATION
# ----------------
if [ $# -ne 1 ]; then
    echo "Usage: $0 <company_name>"
    exit 1
fi

COMPANY="$1"
# -----------
#  PATH SETUP
# ------------
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
SCOPE_FILE="$BASE_DIR/scope_${COMPANY}.txt"
HASH_OUTPUT="$BASE_DIR/data/httpx_subdomains/favicon_hashes.txt"
HTTPX_FINAL_SUBS_PLAIN="$BASE_DIR/data/subdomains_organized/httpx_final_subs_plain.txt"
UNCOVER_FAVICON_IPS_SHODAN="$BASE_DIR/data/ips/uncover_shodan-favicon_ips.txt"
UNCOVER_SHODAN_IPS="$BASE_DIR/data/ips/uncover_shodan-ssl_ips.txt"
DNSX_A_RECORD_OUTPUT="$BASE_DIR/data/ips/dnsx-a-record_ips.txt"
DNSX_AAAA_RECORD_OUTPUT="$BASE_DIR/data/ips/dnsx-aaaa-record_ips.txt"
DNSX_ANY_RECORD_OUTPUT="$BASE_DIR/data/ips/dnsx-any-record_ips.txt"
SHODAN_PASSIVE_DNS_RECORDS="$BASE_DIR/data/ips/shodan-passive-dns-records.txt"
UNCOVER_FAVICON_IPS_FOFA="$BASE_DIR/data/ips/uncover_fofa-favicon_ips.txt"
UNCOVER_FOFA_CERT_IPS="$BASE_DIR/data/ips/uncover_fofa-ssl_ips.txt"
UNCOVER_FOFA_CERT_SUBJECT_IPS="$BASE_DIR/data/ips/uncover_fofa-subject-cn_ips.txt"
UNCOVER_FOFA_DOMAIN_QUERY_IPS="$BASE_DIR/data/ips/uncover_fofa-domain-query_ips.txt"
CENSYS_IPS="$BASE_DIR/data/ips/censys_ips.txt"
CENSYS_CN_IPS="$BASE_DIR/data/ips/censys_cn_ips.txt"
UNCOVER_CRIMINALIP_IPS="$BASE_DIR/data/ips/uncover-criminalip-ips.txt"
UNCOVER_QUAKE_IPS="$BASE_DIR/data/ips/uncover-quake-ips.txt"

mkdir -p "$BASE_DIR/data/ips"

# -----------------------
# Run uncover for each unique favicon hash using shodan
# -----------------------
echo "[*] Finding IPs using favicon hashses through shodan..."
grep -oP '\[\-?\d+\]' "$HASH_OUTPUT" | sort -u | while read -r hash; do
    uncover -q "http.favicon.hash:$hash" -e shodan -silent -l 100000 -pc /root/.config/uncover/provider-config.yaml 
done | sort -u > "$UNCOVER_FAVICON_IPS_SHODAN"
echo "[+] uncover (shodan) through hashes found $(wc -l < "$UNCOVER_FAVICON_IPS_SHODAN") IPs"

# -----------------------
# Run uncover with shodan
# -----------------------
echo "[*] Finding IPs generally using shodan..."
while read -r domain; do
    uncover -q "ssl:$domain" -q "ssl.cert.subject.cn:$domain" -q "hostname:$domain" -q "ssl.cert.expired:true hostname:$domain" -e shodan -silent -l 100000 -pc /root/.config/uncover/provider-config.yaml  | sort -u | awk -F: '{print $1}'
done < "$SCOPE_FILE" | sort -u > "$UNCOVER_SHODAN_IPS"
echo "[+] uncover (shodan) generally found $(wc -l < "$UNCOVER_SHODAN_IPS") IPs"

# -----------------------
# Shodan passive DNS records
# -----------------------
echo "[*] Finding IPs through passive DNS using Shodan..."
while read -r domain; do
    shodan domain "$domain" | grep -Eo '([0-9]{1,3}\.){3}[0-9]{1,3}'
done < "$SCOPE_FILE" | sort -u > "$SHODAN_PASSIVE_DNS_RECORDS"
echo "[+] Shodan passive DNS records found $(wc -l < "$SHODAN_PASSIVE_DNS_RECORDS") IPs"

# ╭────────────────────────────╮
# |   FOFA - FAVICON HASHES    |
# ╰────────────────────────────╯
echo "[*] Finding IPs using favicon hashes through fofa..."
FOFA_TOKEN=$(grep '^FOFA_TOKEN_IN_COOKIE=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)

grep -oP '\[\-?\d+\]' "$HASH_OUTPUT" | sort -u | while read -r hash; do
    page=1
    while true; do
        query="icon_hash=\"$hash\""
        qbase64=$(echo -n "$query" | base64)

        ips=$(curl -s "https://en.fofa.info/result?qbase64=$qbase64&page=$page&page_size=50" \
          -H "Cookie: fofa_token=$FOFA_TOKEN" \
          -H "User-Agent: Mozilla/5.0" \
          --compressed \
          | grep -oP '([0-9]{1,3}\.){3}[0-9]{1,3}')

        if [ -z "$ips" ]; then
            break
        fi

        echo "$ips"
        page=$((page+1))
    done
done | sort -u > "$UNCOVER_FAVICON_IPS_FOFA"

echo "[+] FOFA (favicon hashes) found $(wc -l < "$UNCOVER_FAVICON_IPS_FOFA") IPs"

# ╭────────────────────────────╮
# |       FOFA - CERT=DOMAIN   |
# ╰────────────────────────────╯
echo "[*] Finding IPs using fofa with cert=domain..."
FOFA_TOKEN=$(grep '^FOFA_TOKEN_IN_COOKIE=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)

while read -r domain; do
    page=1
    while true; do
        query="cert=\"$domain\""
        qbase64=$(echo -n "$query" | base64)

        ips=$(curl -s "https://en.fofa.info/result?qbase64=$qbase64&page=$page&page_size=50" \
          -H "Cookie: fofa_token=$FOFA_TOKEN" \
          -H "User-Agent: Mozilla/5.0" \
          --compressed \
          | grep -oP '([0-9]{1,3}\.){3}[0-9]{1,3}' | awk -F: '{print $1}')

        if [ -z "$ips" ]; then
            break
        fi

        echo "$ips"
        page=$((page+1))
    done
done < "$SCOPE_FILE" | sort -u > "$UNCOVER_FOFA_CERT_IPS"

echo "[+] FOFA (cert=domain) found $(wc -l < "$UNCOVER_FOFA_CERT_IPS") IPs"


# ╭──────────────────────────────────────╮
# |     FOFA - CERT SUBJECT CN DOMAINS   |
# ╰──────────────────────────────────────╯
echo "[*] Finding IPs generally using fofa..."
FOFA_TOKEN=$(grep '^FOFA_TOKEN_IN_COOKIE=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)

while read -r domain; do
    page=1
    while true; do
        query="cert.subject.cn=\"$domain\""
        qbase64=$(echo -n "$query" | base64)

        ips=$(curl -s "https://en.fofa.info/result?qbase64=$qbase64&page=$page&page_size=50" \
          -H "Cookie: fofa_token=$FOFA_TOKEN" \
          -H "User-Agent: Mozilla/5.0" \
          --compressed \
          | grep -oP '([0-9]{1,3}\.){3}[0-9]{1,3}' | awk -F: '{print $1}')

        if [ -z "$ips" ]; then
            break
        fi

        echo "$ips"
        page=$((page+1))
    done
done < "$SCOPE_FILE" | sort -u > "$UNCOVER_FOFA_CERT_SUBJECT_IPS"

echo "[+] FOFA (general domains) found $(wc -l < "$UNCOVER_FOFA_CERT_SUBJECT_IPS") IPs"

# ╭────────────────────────────╮
# |     FOFA - DOMAIN QUERY    |
# ╰────────────────────────────╯
echo "[*] Finding IPs using fofa domain query..."
FOFA_TOKEN=$(grep '^FOFA_TOKEN_IN_COOKIE=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)

while read -r domain; do
    page=1
    while true; do
        query="domain=\"$domain\""
        qbase64=$(echo -n "$query" | base64)

        ips=$(curl -s "https://en.fofa.info/result?qbase64=$qbase64&page=$page&page_size=50" \
          -H "Cookie: fofa_token=$FOFA_TOKEN" \
          -H "User-Agent: Mozilla/5.0" \
          --compressed \
          | grep -oP '([0-9]{1,3}\.){3}[0-9]{1,3}' | awk -F: '{print $1}')

        if [ -z "$ips" ]; then
            break
        fi

        echo "$ips"
        page=$((page+1))
    done
done < "$SCOPE_FILE" | sort -u > "$UNCOVER_FOFA_DOMAIN_QUERY_IPS"

echo "[+] FOFA (domain query) found $(wc -l < "$UNCOVER_FOFA_DOMAIN_QUERY_IPS") IPs"

# ╭────────────────────────────╮
# |     Finding IPs - Censys   |
# ╰────────────────────────────╯

echo "[*] Finding IPs from censys..."
while IFS= read -r domain; do
    sleep 10
    curl -s "https://search.censys.io/_search?resource=hosts&sort=RELEVANCE&per_page=100&virtual_hosts=EXCLUDE&q=services.tls.certificates.leaf_data.names%3A+$domain" \
         -H 'Cookie: ' \
         -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0' \
         --compressed \
         | grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' \
         | sort -u >> "$CENSYS_IPS"
done < "$SCOPE_FILE"
echo "[+] Total unique censys IPs: $(sort -u "$CENSYS_IPS" | wc -l)"

# ╭───────────────────────────────╮
# |  Finding IPs - Censys (CN)   |
# ╰───────────────────────────────╯

echo "[*] Finding IPs from censys (common_name)..."
while IFS= read -r domain; do
    sleep 10
    curl -s "https://search.censys.io/_search?resource=hosts&sort=RELEVANCE&per_page=100&virtual_hosts=EXCLUDE&q=services.tls.certificates.leaf_data.subject.common_name%3A+$domain" \
         -H 'Cookie: ' \
         -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0' \
         --compressed \
         | grep -oE '\b([0-9]{1,3}\.){3}[0-9]{1,3}\b' \
         | sort -u >> "$CENSYS_CN_IPS"
done < "$SCOPE_FILE"
echo "[+] Total unique censys CN IPs: $(sort -u "$CENSYS_CN_IPS" | wc -l)"

# -----------------------
# Run uncover with quake
# -----------------------
echo "[*] Finding IPs generally using quake..."
while read -r domain; do
    uncover -q "cert:$domain" -q "domain:$domain" -e quake -silent -l 100000 -pc /root/.config/uncover/provider-config.yaml  | awk -F: '{print $1}'
done < "$SCOPE_FILE" | sort -u > "$UNCOVER_QUAKE_IPS"
echo "[+] uncover (quake) generally found $(wc -l < "$UNCOVER_QUAKE_IPS") IPs"

# -----------------------
# Run uncover with criminalip
# -----------------------
echo "[*] Finding IPs generally using criminalip..."
while read -r domain; do
    uncover -q "cert:$domain" -q "ssl_expired:true hostname:$domain" -e criminalip -silent -l 100000 -pc /root/.config/uncover/provider-config.yaml  | awk -F: '{print $1}'
done < "$SCOPE_FILE" | sort -u > "$UNCOVER_CRIMINALIP_IPS"
echo "[+] uncover (criminalip) generally found $(wc -l < "$UNCOVER_CRIMINALIP_IPS") IPs"

# -----------------------
# IPs from A record
# -----------------------
echo "[*] Running dnsx A record IPs..."
cat "$HTTPX_FINAL_SUBS_PLAIN" | dnsx -a -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 | sort -u > "$DNSX_A_RECORD_OUTPUT"
echo "[+] dnsx A record found $(wc -l < "$DNSX_A_RECORD_OUTPUT") IPs"

# -----------------------
# IPs from AAAA record
# -----------------------
echo "[*] Running dnsx AAAA record IPs..."
cat "$HTTPX_FINAL_SUBS_PLAIN" | dnsx -aaaa -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 | sort -u > "$DNSX_AAAA_RECORD_OUTPUT"
echo "[+] dnsx AAAA record found $(wc -l < "$DNSX_AAAA_RECORD_OUTPUT") IPs"

# -----------------------
# IPs from ANY record
# -----------------------
echo "[*] Running dnsx ANY record IPs..."
cat "$HTTPX_FINAL_SUBS_PLAIN" | dnsx -any -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 | sort -u > "$DNSX_ANY_RECORD_OUTPUT"
echo "[+] dnsx ANY record found $(wc -l < "$DNSX_ANY_RECORD_OUTPUT") IPs"

# -----------------------
# 🔹 FINAL IP CONSOLIDATION
# -----------------------
echo "[*] Combining all IPs from tools..."

find "$BASE_DIR/data/ips" -type f -name "*.txt" -exec cat {} + | sort -u | grep -Ev '[a-zA-Z]' > "$BASE_DIR/data/ips/final_ips.txt"

echo "[+] Total unique IPs collected: $(wc -l < "$BASE_DIR/data/ips/final_ips.txt")"

