#!/bin/bash

# ─────────────────
# Input validation
# ─────────────────
if [ $# -ne 1 ]; then echo "Usage: $0 <company_name>"; exit 1; fi
COMPANY="$1"

# Paths
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
FINAL_SUBS="$BASE_DIR/data/subdomains/final_subdomains.txt"
SUBS_WITH_PORTS="$BASE_DIR/data/subs_with_ports/subs_with_ports.txt"
HTTPX_SUBDOMAINS_DIR="$BASE_DIR/data/httpx_subdomains"
SUBDOMAINS_ORGANIZED_DIR="$BASE_DIR/data/subdomains_organized"

# Create directories
mkdir -p "$HTTPX_SUBDOMAINS_DIR" "$SUBDOMAINS_ORGANIZED_DIR" "$SUBDOMAINS_ORGANIZED_DIR/http-title_urls"

# Run httpx
touch "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs_unfiltered.txt"
touch "$HTTPX_SUBDOMAINS_DIR/httpx_subs_with_ports_unfiltered.txt"

echo "[*] Running httpx on final subs..."
cat "$FINAL_SUBS" | httpx -silent -nc -threads 15 -rate-limit 30 -timeout 15 -sc -location -cl -ct -title -server -asn -ip -cdn -favicon -td -o "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs_unfiltered.txt"
echo "[✔] httpx scan completed. Total $(wc -l < "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs_unfiltered.txt") unfiltered lines."

echo "[*] Running httpx on subs_with_ports..."
cat "$SUBS_WITH_PORTS" | httpx -silent -nc -threads 15 -rate-limit 30 -timeout 15 -sc -location -cl -ct -title -server -asn -ip -cdn -favicon -td -o "$HTTPX_SUBDOMAINS_DIR/httpx_subs_with_ports_unfiltered.txt"
echo "[✔] httpx scan completed. Total $(wc -l < "$HTTPX_SUBDOMAINS_DIR/httpx_subs_with_ports_unfiltered.txt") unfiltered lines."

# Merge and filter
cat $HTTPX_SUBDOMAINS_DIR/httpx_final_subs_unfiltered.txt $HTTPX_SUBDOMAINS_DIR/httpx_subs_with_ports_unfiltered.txt | sort -u > "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs-subs_with_ports_unfiltered.txt"

# Favicon hashes, subs with http-https, plain subs
grep -oP '\[\K[+-]?[0-9]{7,}(?=\])' "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs-subs_with_ports_unfiltered.txt" > "$HTTPX_SUBDOMAINS_DIR/favicon_hashes.txt"
echo "[✔] Extracted $(wc -l < "$HTTPX_SUBDOMAINS_DIR/favicon_hashes.txt") favicon hashes."

awk '{print $1}' "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs-subs_with_ports_unfiltered.txt" > "$SUBDOMAINS_ORGANIZED_DIR/httpx_final_subs_with_http-https.txt"
echo "[✔] Created httpx_final_subs_with_http-https.txt with $(wc -l < "$SUBDOMAINS_ORGANIZED_DIR/httpx_final_subs_with_http-https.txt") lines."

sed -E 's~^https?://~~' "$SUBDOMAINS_ORGANIZED_DIR/httpx_final_subs_with_http-https.txt" > "$SUBDOMAINS_ORGANIZED_DIR/httpx_final_subs_plain.txt"
echo "[✔] Created httpx_final_subs_plain.txt with $(wc -l < "$SUBDOMAINS_ORGANIZED_DIR/httpx_final_subs_plain.txt") lines."

# Organize by root domain and status
echo "[*] Organizing HTTPX output by Root Domains & Status Codes..."
while IFS= read -r line || [ -n "$line" ]; do
    URL=$(echo "$line" | awk '{print $1}')
    STATUS=$(echo "$line" | awk '{print $2}' | tr -d '[]')
    LOCATION=$(echo "$line" | awk '{print $3}' | tr -d '[]')
    HOSTPORT_ORIG=$(echo "$URL" | sed -E 's|^[a-zA-Z]+://||' | cut -d'/' -f1)	
    ROOTDOMAIN=$(echo "$HOSTPORT_ORIG" | cut -d':' -f1 | awk -F. '{n=NF; if(n>=2) print $(n-1)"."$n; else print $0}')
    [ -z "$ROOTDOMAIN" ] && ROOTDOMAIN=$(echo "$HOSTPORT_ORIG" | sed 's/[^A-Za-z0-9._-]/_/g')
    [ -z "$ROOTDOMAIN" ] && ROOTDOMAIN="unknown-domain"
    mkdir -p "$SUBDOMAINS_ORGANIZED_DIR/domains/$ROOTDOMAIN"
    echo "$URL" >> "$SUBDOMAINS_ORGANIZED_DIR/domains/$ROOTDOMAIN/${ROOTDOMAIN}.txt"
    echo "$URL" >> "$SUBDOMAINS_ORGANIZED_DIR/domains/$ROOTDOMAIN/${STATUS}.txt"
done < "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs-subs_with_ports_unfiltered.txt"
echo "[✔] Organization by root domain and status code completed."

# Combine status code files
for FILE in "$SUBDOMAINS_ORGANIZED_DIR"/domains/*/*.txt; do
    [ -e "$FILE" ] || continue
    CODE=$(basename "$FILE" .txt)
    if [[ "$CODE" =~ ^[0-9]{3}$ ]]; then
        cat "$SUBDOMAINS_ORGANIZED_DIR"/domains/*/"$CODE".txt 2>/dev/null | sort -u > "$SUBDOMAINS_ORGANIZED_DIR/all_${CODE}.txt"
        echo "[✔] Combined all $CODE files into all_${CODE}.txt"
    fi
done

# Organize by HTTP title
echo "[*] Organizing URLs by HTTP Title..."
while IFS= read -r rec || [ -n "$rec" ]; do
    URL="${rec%% *}"
    mapfile -t FIELDS < <(printf "%s\n" "$rec" | grep -o '\[[^]]*\]' | sed 's/^\[//; s/\]$//')
    TITLE="${FIELDS[4]:-}"
    EIGHTH="${FIELDS[6]:-}"
    if [[ "$EIGHTH" =~ ^AS[0-9]+$ || "$EIGHTH" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        SAFE_TITLE=$(printf "%s" "$TITLE" | sed 's#[/:*?"<>|&$!`'"'"' \t\r\n]#_#g')
        [ -z "$SAFE_TITLE" ] && SAFE_TITLE="EMPTY"
    else
        SAFE_TITLE="EMPTY"
    fi
    echo "$URL" >> "$SUBDOMAINS_ORGANIZED_DIR/http-title_urls/${SAFE_TITLE}.txt"
done < <(sed -E 's#[[:space:]]+(https?://)#\n\1#g' "$HTTPX_SUBDOMAINS_DIR/httpx_final_subs-subs_with_ports_unfiltered.txt" | sed '/^\s*$/d')
TITLE_FILES_COUNT=$(find "$SUBDOMAINS_ORGANIZED_DIR/http-title_urls" -type f -name '*.txt' | wc -l)
echo "[✔] Created $TITLE_FILES_COUNT title-based files in http-title_urls"
