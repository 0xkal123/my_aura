cat subdomains.txt | httpx -nc threads 4 -rate-limit 5 -timeout 15 -extract-fqdn
