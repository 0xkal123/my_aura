#!/bin/bash

# Check for company name input
if [ -z "$1" ]; then
    echo "Usage: $0 <company name>"
    exit 1
fi

COMPANY=$1
TARGET_DIR="/root/Desktop/BB/recon/$COMPANY/data/ips"
OUTPUT_DIR="/root/Desktop/BB/recon/$COMPANY/data/subdomains"
FINAL_IPS="$TARGET_DIR/final_ips.txt"

# ================================
# 🔹 Subs from PTR records
# ================================
echo -e "\n[*] Running dnsx PTR records..."
cat "$FINAL_IPS" | dnsx -ptr -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 | sort -u > "$OUTPUT_DIR/subs_from_PTR_records.txt"
echo "[✔] PTR scan completed."w
echo "[-] Found $(wc -l < "$OUTPUT_DIR/subs_from_PTR_records.txt") subdomains from PTR records."
sleep 1

# ╭────────────────────────────╮
# |     IN-SCOPE FILTERING     |
# ╰────────────────────────────╯
echo -e "\n[*] Combining all subdomain files..."
cat *.txt | sort -u > sorted_subdomains-ptr-rec_subs.txt
echo "[+] Combined $(wc -l < sorted_subdomains-ptr-rec_subs.txt) subdomains before scope filtering"

echo -e "\n[*] Filtering in-scope subdomains..."
# First filter with scope file
while read -r domain; do
    grep -E "(\.|^)${domain}$" sorted_subdomains-ptr-rec_subs.txt
done < "$SCOPE_FILE" > dsieve_filtered-ptr-rec_subs.txt

echo -e "\n[*] Applying dsieve filtering..."
dsieve -if dsieve_filtered-ptr-rec_subs.txt | sort -u > subs_from_active-passive.txt

echo "[✔] In-scope and dsieve filtering completed."
echo "[-] Final filtered subdomains count: $(wc -l < subs_from_active-passive.txt)"
