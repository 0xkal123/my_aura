#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $0 <company>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon"
SCOPE_FILE="$BASE_DIR/$COMPANY/scope_$COMPANY.txt"
TARGET_DIR="$BASE_DIR/$COMPANY/data/subdomains"

# Check if the scope file exists
if [ ! -f "$SCOPE_FILE" ]; then
    echo "[!] Input file not found: $SCOPE_FILE"
    exit 1
fi

mkdir -p "$TARGET_DIR"
cd "$TARGET_DIR" || exit

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |      SUBFINDER       |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Subfinder..."
subfinder -dL "$SCOPE_FILE" -all -recursive -silent -nc -config ~/.config/subfinder/config.yaml -provider-config ~/.config/subfinder/provider-config.yaml -o subfinder.txt
echo "[-] Subfinder found $(wc -l < subfinder.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |     ASSETFINDER      |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Assetfinder..."
while read -r domain; do
    assetfinder --subs-only "$domain"
done < "$SCOPE_FILE" > assetfinder.txt
echo "[-] Assetfinder found $(wc -l < assetfinder.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |      SUBLIST3R       |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Sublist3r..."

> sublist3r.txt   # ensure file always exists (fix for your error)

while read -r domain; do
    python3 /root/Desktop/tools/Sublist3r/sublist3r.py -d "$domain" -n -e baidu,yahoo,google,bing,ask,netcraft,dnsdumpster,threatcrowd,ssl,passivedns -o temp.txt
    if [ -s temp.txt ]; then
        cat temp.txt >> sublist3r.txt
    fi
    rm -f temp.txt
done < "$SCOPE_FILE"

echo "[-] Sublist3r found $(wc -l < sublist3r.txt) subdomains."

sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |        CRT.SH        |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running crt.sh..."
rm -f crtsh.txt  # Clean old merged file
while read -r domain; do
    /root/Desktop/tools/crt.sh/./crt_v2.sh -d "$domain" || echo "[-] crt.sh failed for $domain"
    # If domain output file exists, append to main crtsh.txt
    if [ -f "domain.${domain}.txt" ]; then
        cat "domain.${domain}.txt" >> crtsh.txt
        rm -f "domain.${domain}.txt"
    fi
done < "$SCOPE_FILE"

if [ -s crtsh.txt ]; then
    echo "[+] crt.sh found $(wc -l < crtsh.txt) subdomains."
else
    echo "[-] crt.sh found 0 subdomains."
    > crtsh.txt  # ensure empty file exists
fi
sleep 1


# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |       CROBAT         |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Crobat..."
crobat -s "$SCOPE_FILE" > crobat.txt
echo "[-] Crobat found $(wc -l < crobat.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |        CHAOS         |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Chaos..."
PDCP_API_KEY=$(grep '^PDCP_API_KEY=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)
chaos -dL "$SCOPE_FILE" -key $PDCP_API_KEY -silent 2>&1 | tee chaos.txt >/dev/null
echo "[-] Chaos found $(wc -l < chaos.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |      SHOSUBGO        |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Shosubgo..."
SHODAN_API_KEY=$(grep '^SHODAN_API_KEY=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)
shosubgo -f "$SCOPE_FILE" -s $SHODAN_API_KEY > shosubgo.txt
echo "[-] Shosubgo found $(wc -l < shosubgo.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# | GITHUB-SUBDOMAINS    |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Github Subdomains..."
GITHUB_TOKEN=$(grep '^GITHUB_TOKEN=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)
while read -r domain; do
    github-subdomains -d "$domain" -t $GITHUB_TOKEN -raw
done < "$SCOPE_FILE" > github_subdomains.txt
echo "[-] Github-Subdomains found $(wc -l < github_subdomains.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# | GITLAB-SUBDOMAINS    |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running GitLab Subdomains..."
GITLAB_TOKEN=$(grep '^GITLAB_TOKEN=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)
while read -r domain; do
    gitlab-subdomains -d "$domain" -t "$GITLAB_TOKEN"
done < "$SCOPE_FILE" > gitlab_subdomains.txt
echo "[-] GitLab-Subdomains found $(wc -l < gitlab_subdomains.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |        CTFR          |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running CTFR..."
> ctfr.txt
while read -r domain; do
    timeout 180s python3 /root/Desktop/tools/ctfr/ctfr.py -d "$domain" 2>/dev/null \
        | sed 's/^\[[^]]*\] *//' >> ctfr.txt
    [ $? -eq 124 ] && echo "[!] CTFR timed out for $domain"
done < "$SCOPE_FILE"
sort -u ctfr.txt -o ctfr.txt
echo "[-] CTFR found $(wc -l < ctfr.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |      Cero            |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Cero..."
cat "$SCOPE_FILE" | cero -c 5 | sort -u > cero.txt
echo "[-] Cero found $(wc -l < cero.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |   Subdomain Center   |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running Subdomain Center..."
> sc-subs.txt  # Create/clear output file

while read -r domain; do
    [[ -z "$domain" ]] && continue
    curl -s "https://api.subdomain.center/?domain=$domain&engine=cuttlefish" | \
    tr -d '[]" ' | tr ',' '\n' >> sc-subs.txt
done < "$SCOPE_FILE"

sort -u sc-subs.txt -o sc-subs.txt
echo "[-] Subdomain Center found $(wc -l < sc-subs.txt) subdomains."
sleep 1

# â•­â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•®
# |     VirusTotal       |
# â•°â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â•¯
echo -e "\n[*] Running VirusTotal..."
> vt-subs.txt  # Create/clear output file
mkdir -p vt_reports

keys=(
"1d23d9b7dcdc763ce751d7111ed76e7d17905f0224a6e9651f1c6b6a592bf840"
"8dd59b153be9c1e3c9fe023825d35f9f897fbfdb5992aa3d7b6e3a58f1d5ed72"
"93463c465f7dbfd6d590b6cbe48a625b996a4874f67612f102fe2d4e905ec1f9"
"3429187655767a6a726841981709346140e089fd713568c50eeb227f47289f93"
"032b8cc1de2e61f9879d14bcd506fe48c1427ef588401ca08a18016c3b3a0cf2"
"c67ef28fb83309ec559b870afab7b7406107a5a89d87eb136ed0f0dc7d60e601"
"da4215b9da9c0491273db17441412eb2b07487b2aaa8126c1071922051f9ed24"
)

i=0
while read -r domain; do
    [[ -z "$domain" ]] && continue
    key_index=$(( (i / 4) % ${#keys[@]} ))
    apikey=${keys[$key_index]}
    echo "[QUERY] $domain with key $((key_index+1))"

    curl -s "https://www.virustotal.com/vtapi/v2/domain/report?apikey=$apikey&domain=$domain" \
        -o "vt_reports/${domain}.json"

    jq -r '.subdomains[]?, .undetected_urls[][0] | select(.!=null)' "vt_reports/${domain}.json" 2>/dev/null \
        | sed -E 's~https?://([^/]+)/.*~\1~' >> vt-subs.txt

    i=$(( i + 1 ))
done < "$SCOPE_FILE"

sort -u vt-subs.txt -o vt-subs.txt
rm -rf vt_reports
echo "[-] VirusTotal found $(wc -l < vt-subs.txt) subdomains."
sleep 1

# ╭────────────────────────────╮
# |     IN-SCOPE FILTERING     |
# ╰────────────────────────────╯
echo -e "\n[*] Combining all subdomain files..."
cat *.txt | sort -u > sorted_subdomains_active-passive_subs.txt
echo "[+] Combined $(wc -l < sorted_subdomains_active-passive_subs.txt) subdomains before scope filtering"

echo -e "\n[*] Filtering in-scope subdomains..."
# Use grep -Ff to match all subdomains under each domain in SCOPE_FILE
grep -Ff "$SCOPE_FILE" sorted_subdomains_active-passive_subs.txt > dsieve_filtered_active-passive_subs.txt

echo -e "\n[*] Applying dsieve filtering..."
if [ ! -s dsieve_filtered_active-passive_subs.txt ]; then
    echo "[!] No subdomains to filter. Check previous steps."
else
    dsieve -if dsieve_filtered_active-passive_subs.txt | sort -u > pre-subs_from_active-passive.txt
    echo "[✔] In-scope and dsieve filtering completed."
    echo "[-] Final filtered subdomains count: $(wc -l < pre-subs_from_active-passive.txt)"
fi

#############
#############

echo -e "\n[*] Extracting subs using cero..."
cat pre-subs_from_active-passive.txt | cero -c 5 | sort -u > subs_from_active-passive.txt
echo "[-] Found $(wc -l < subs_from_active-passive.txt) subdomains from cero"
sleep 1

#############
#############

# -----------------------
#  Subs from CNAME records
# -----------------------
echo -e "\n[*] Running dnsx CNAME records..."
cat subs_from_active-passive.txt | dnsx -cname -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40 | sort -u > subs_from_cname_records.txt
echo "[-] Found $(wc -l < subs_from_cname_records.txt) subdomains from CNAME records."
sleep 1

# -----------------------
#  Subs from MX records
# -----------------------
echo -e "\n[*] Running dnsx MX records..."
cat subs_from_active-passive.txt | dnsx -mx -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_mx_records.txt
echo "[-] Found $(wc -l < subs_from_mx_records.txt) subdomains from MX records."
sleep 1

# -----------------------
#  Subs from NS records
# -----------------------
echo -e "\n[*] Running dnsx NS records..."
cat subs_from_active-passive.txt | dnsx -ns -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_ns_records.txt
echo "[-] Found $(wc -l < subs_from_ns_records.txt) subdomains from NS records."
sleep 1

# -----------------------
#  Subs from SRV records
# -----------------------
echo -e "\n[*] Running dnsx SRV records..."
cat subs_from_active-passive.txt | dnsx -srv -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_srv_records.txt
echo "[-] Found $(wc -l < subs_from_srv_records.txt) subdomains from SRV records."
sleep 1

# -----------------------
#  Subs from PTR records
# -----------------------
echo -e "\n[*] Running dnsx PTR records..."
cat subs_from_active-passive.txt | dnsx -ptr -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_ptr_records.txt
echo "[-] Found $(wc -l < subs_from_ptr_records.txt) subdomains from PTR records."
sleep 1

# -----------------------
#  Subs from TXT records
# -----------------------
echo -e "\n[*] Running dnsx TXT records..."
cat subs_from_active-passive.txt | dnsx -txt -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_txt_records.txt
echo "[-] Found $(wc -l < subs_from_txt_records.txt) subdomains from TXT records."
sleep 1

# -----------------------
#  Subs from ANY records
# -----------------------
echo -e "\n[*] Running dnsx ANY records..."
cat subs_from_active-passive.txt | dnsx -any -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_any_records.txt
echo "[-] Found $(wc -l < subs_from_any_records.txt) subdomains from ANY records."
sleep 1

# -----------------------
#  Subs from AXFR records
# -----------------------
echo -e "\n[*] Running dnsx AXFR records..."
cat subs_from_active-passive.txt | dnsx -axfr -ro -silent -r /root/Desktop/BB/resolvers/resolvers_trusted_31-lines.txt -t 40  | sort -u > subs_from_axfr_records.txt
echo "[-] Found $(wc -l < subs_from_axfr_records.txt) subdomains from AXFR records."
sleep 1

# ╭────────────────────────────╮
# |     IN-SCOPE FILTERING     |
# ╰────────────────────────────╯
echo -e "\n[*] Combining all subdomain files..."
cat *.txt | sort -u > sorted_subdomains_dns-records_subs.txt
echo "[+] Combined $(wc -l < sorted_subdomains_dns-records_subs.txt) subdomains before scope filtering"

echo -e "\n[*] Filtering in-scope subdomains..."
# Match all subdomains under each domain in SCOPE_FILE
grep -Ff "$SCOPE_FILE" sorted_subdomains_dns-records_subs.txt > dsieve_filtered_dns-records_subs.txt

echo -e "\n[*] Applying dsieve filtering..."
if [ ! -s dsieve_filtered_dns-records_subs.txt ]; then
    echo "[!] No subdomains to filter. Check previous steps."
else
    dsieve -if dsieve_filtered_dns-records_subs.txt | sort -u > final_subdomains.txt
    echo "[✔] In-scope and dsieve filtering completed."
    echo "[-] Final filtered subdomains count: $(wc -l < final_subdomains.txt)"
fi

# ================================
#  Extract Wildcard Subdomains
# ================================
echo -e "\n[*] Extracting wildcard subdomains..."
grep '^\*\.' final_subdomains.txt > wildcards.txt
echo "[âœ”] Wildcard extraction completed."
echo "[-] Found $(wc -l < wildcards.txt) wildcard subdomains."
sleep 1