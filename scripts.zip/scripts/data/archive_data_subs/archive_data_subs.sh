#!/bin/bash

# =============================
# 🔹 ARCHIVE DATA FOR EACH SUBDOMAIN
# =============================

if [ $# -ne 1 ]; then
    echo "Usage: $0 <company_name>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
SCOPE_FILE="$BASE_DIR/scope_${COMPANY}.txt"
SUBS_FILE="$BASE_DIR/data/subdomains_organized/httpx_final_subs_plain.txt"

[ ! -f "$SCOPE_FILE" ] && echo "[✘] Scope file not found" && exit 1
[ ! -f "$SUBS_FILE" ] && echo "[✘] Subdomains file not found" && exit 1

exec 3< <(grep -v ':' "$SUBS_FILE")

while IFS= read -r domain <&3; do

    DOMAIN_DIR="$BASE_DIR/data/archive_data_subs/$domain"
    FINAL_FILE="$DOMAIN_DIR/all_archive.txt"

    # ---------------- DOMAIN RESUME ----------------
    if [ -s "$FINAL_FILE" ]; then
        echo "[⏩] Skipping $domain (already completed)"
        continue
    fi

    echo -e "\n[+] Starting Archive Collection for: $domain"
    mkdir -p "$DOMAIN_DIR"

    # ---------------- WAYBACKURLS ----------------
    WB="$DOMAIN_DIR/${domain}_waybackurls.txt"
    if [ -s "$WB" ]; then
        echo "[⏩] Waybackurls already done — skipping"
    else
        echo "[•] Running Waybackurls for $domain ..."
        echo "$domain" | waybackurls -no-subs | grep -v '^[[:space:]]*$' | anew -q "$WB"
        echo "[✓] Waybackurls for $domain found $(wc -l < "$WB") urls"
    fi
    echo ""

    # ---------------- GAU ----------------
    GAU="$DOMAIN_DIR/${domain}_gau.txt"
    if [ -s "$GAU" ]; then
        echo "[⏩] GAU already done — skipping"
    else
        echo "[•] Running GAU for $domain ..."
        echo "$domain" | gau --providers commoncrawl,otx,urlscan \
            --config /root/.gau.toml --retries 2 --threads 5 --timeout 10 \
            | anew -q "$GAU"
        echo "[✓] GAU for $domain found $(wc -l < "$GAU") urls"
    fi
    echo ""

    # ---------------- GITHUB ENDPOINTS ----------------
    GH="$DOMAIN_DIR/${domain}_github-endpoints.txt"
    GITHUB_TOKEN=$(grep '^GITHUB_TOKEN=' ~/Desktop/scripts/CONFIG.TXT | cut -d '=' -f2)

    if [ -s "$GH" ]; then
        echo "[⏩] github-endpoints already done — skipping"
    else
        echo "[•] Running github-endpoints for $domain ..."
        github-endpoints -d "$domain" -t "$GITHUB_TOKEN" -raw | tee -a "$GH"
        echo "[✓] github-endpoints for $domain found $(wc -l < "$GH") urls"
    fi
    echo ""

    # ---------------- HAKRAWLER ----------------
    HK="$DOMAIN_DIR/${domain}_hakrawler.txt"
    if [ -s "$HK" ]; then
        echo "[⏩] Hakrawler already done — skipping"
    else
        echo "[•] Running Hakrawler for $domain ..."
        echo "https://$domain" | hakrawler -d 0 -insecure -t 25 -timeout 15 | anew -q "$HK"
        echo "[✓] Hakrawler for $domain found $(wc -l < "$HK") urls"
    fi
    echo ""

    # ---------------- GOSPIDER ----------------
    GS="$DOMAIN_DIR/${domain}_gospider.txt"
    if [ -s "$GS" ]; then
        echo "[⏩] Gospider already done — skipping"
    else
        echo "[•] Running Gospider for $domain ..."
        gospider -s "https://$domain" --quiet --depth 5 --threads 80 \
            --js --robots --other-source --include-other-source \
            --sitemap --no-redirect --raw | anew -q "$GS"
        echo "[✓] Gospider for $domain found $(wc -l < "$GS") urls"
    fi
    echo ""

    # ---------------- URLGRAB ----------------
    UG="$DOMAIN_DIR/${domain}_urlgrab.txt"
    if [ -s "$UG" ]; then
        echo "[⏩] urlgrab already done — skipping"
    else
        echo "[•] Running urlgrab for $domain ..."
        urlgrab -url "https://$domain" -depth 9 -threads 80 -timeout 10 \
            -js-timeout 10 -ignore-ssl -random-agent -delay 1000 \
            | grep -v '^[[:space:]]*$' | anew -q "$UG"
        echo "[✓] urlgrab for $domain found $(wc -l < "$UG") urls"
    fi
    echo ""

    # ---------------- KATANA DF ----------------
    KDF="$DOMAIN_DIR/${domain}_katana_df.txt"
    if [ -s "$KDF" ]; then
        echo "[⏩] Katana DF already done — skipping"
    else
        echo "[•] Running Katana Active DF for $domain ..."
        echo "$domain" | katana -d 9 -jc -jsl -xhr -aff -fx \
            -s depth-first -ct 2m -c 20 -rl 10 -silent | anew -q "$KDF"
        echo "[✓] Katana DF for $domain found $(wc -l < "$KDF") urls"
    fi
    echo ""

    # ---------------- KATANA BF ----------------
    KBF="$DOMAIN_DIR/${domain}_katana_bf.txt"
    if [ -s "$KBF" ]; then
        echo "[⏩] Katana BF already done — skipping"
    else
        echo "[•] Running Katana Active BF for $domain ..."
        echo "$domain" | katana -d 9 -jc -jsl -xhr -aff -fx \
            -s breadth-first -ct 2m -c 20 -rl 10 -silent | anew -q "$KBF"
        echo "[✓] Katana BF for $domain found $(wc -l < "$KBF") urls"
    fi
    echo ""

    # ---------------- BUILD ARCHIVE ----------------
    echo "[•] Building pre_all_archive for $domain"

    cat "$DOMAIN_DIR"/*.txt \
      | awk -v d="$domain" 'BEGIN{IGNORECASE=1}
        /^https?:\/\// {split($0,a,"/"); if (a[3]==d) print $0}' \
      | sort -u > "$DOMAIN_DIR/pre_all_archive.txt"

    JS_WORKING="$DOMAIN_DIR/js_urls_working.txt"
    grep -Ei '\.js($|\?)' "$DOMAIN_DIR/pre_all_archive.txt" \
        | httpx -silent -mc 200 -ct | awk '{print $1}' > "$JS_WORKING"

    grep -vEi '\.(png|jpg|jpeg|gif|svg|css|ico|woff|woff2|ttf|otf)(\?|$)' \
        "$DOMAIN_DIR/pre_all_archive.txt" | sort -u > "$FINAL_FILE"

    echo "[📊] Total URLs found for $domain: $(wc -l < "$FINAL_FILE")"

    # ---------------- FINAL CLEANUP ----------------
    echo "[•] Final cleanup for $domain (keeping only final files)"
    find "$DOMAIN_DIR" -type f \
        ! -name "all_archive.txt" \
        ! -name "js_urls_working.txt" \
        -exec rm -f {} +

    echo "[✓] Cleanup done for $domain"

done

exec 3<&-

# ---------------- FINAL CONSOLIDATION ----------------
find "$BASE_DIR/data/archive_data_subs" -type f -name "all_archive.txt" \
    -exec cat {} + | sort -u > "$BASE_DIR/data/archive_data_subs/final_all_archive.txt"

echo "[✔] final_all_archive.txt created with $(wc -l < "$BASE_DIR/data/archive_data_subs/final_all_archive.txt") urls"
