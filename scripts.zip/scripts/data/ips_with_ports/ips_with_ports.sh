#!/bin/bash

# ================================
# Grabbing ports on FINAL_IPS using shodanidb
# ================================

if [ -z "$1" ]; then
  echo "Usage: ./shodanidb.sh <company>"
  exit 1
fi

COMPANY=$1
FINAL_IPS="/root/Desktop/BB/recon/$COMPANY/data/ips/final_ips.txt"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"

[ -s "$FINAL_IPS" ] || { echo "[✖] Missing or empty file: $FINAL_IPS"; exit 1; }

mkdir -p "$BASE_DIR/data/ips_with_ports"

echo -e "\n[*] Finding Ports on final_ips.txt for $COMPANY..."
> "$BASE_DIR/data/ips_with_ports/ips_with_ports.txt"

i=0; total=$(wc -l < "$FINAL_IPS" 2>/dev/null || echo 0)

while read -r ip; do
  [ -z "$ip" ] && continue
  i=$((i+1))

  ports=$(python3 - "$ip" <<'END'
import json, urllib.request, sys
ip = sys.argv[1]
try:
    url = f"https://internetdb.shodan.io/{ip}"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        data = json.loads(resp.read().decode())
        print(",".join(str(p) for p in data.get("ports", [])))
except Exception:
    pass
END
)

  if [ -n "$ports" ]; then
    IFS=',' read -ra arr <<< "$ports"

    found_any=false
    only_80443=true
    declare -A seen=()

    for p in "${arr[@]}"; do
      [[ "$p" =~ ^[0-9]+$ ]] || continue
      if [[ "$p" -eq 80 || "$p" -eq 443 ]]; then
        continue
      fi
      only_80443=false
      if [[ -z "${seen[$p]}" ]]; then
        echo "$ip:$p" >> "$BASE_DIR/data/ips_with_ports/ips_with_ports.txt"
        seen[$p]=1
        found_any=true
      fi
    done

    if $found_any; then
      # Show only the saved ports (ex-80/443) in the progress line
      saved=$(grep -F "^$ip:" "$BASE_DIR/data/ips_with_ports/ips_with_ports.txt" | cut -d: -f2 | tr '\n' ',' | sed 's/,$//')
      echo "[+] ($i/$total) $ip → $saved"
    elif $only_80443; then
      echo "[!] ($i/$total) $ip → only 80/443 found – skipping"
    else
      echo "[-] ($i/$total) $ip → no usable ports"
    fi
  else
    echo "[-] ($i/$total) $ip → no ports"
  fi

  sleep 2
done < "$FINAL_IPS"

echo "[✔] Done. Total $(wc -l < "$BASE_DIR/data/ips_with_ports/ips_with_ports.txt") IP:PORT pairs."
echo "[+] Saved: $BASE_DIR/data/ips_with_ports/ips_with_ports.txt"
