#!/bin/bash

# ─────────────────
# Input validation
# ─────────────────
if [ $# -ne 1 ]; then echo "Usage: $0 <company_name>"; exit 1; fi
COMPANY="$1"

# Paths
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
FINAL_IPS="$BASE_DIR/data/ips/final_ips.txt"
IPS_WITH_PORTS="$BASE_DIR/data/ips_with_ports/ips_with_ports.txt"
HTTPX_IPS_DIR="$BASE_DIR/data/httpx_ips"
IPS_ORGANIZED_DIR="$BASE_DIR/data/ips_organized"

# Create directories
mkdir -p "$HTTPX_IPS_DIR" "$IPS_ORGANIZED_DIR" "$IPS_ORGANIZED_DIR/http-title_urls"

# Run httpx
touch "$HTTPX_IPS_DIR/httpx_final_ips_unfiltered.txt"
touch "$HTTPX_IPS_DIR/httpx_ips_with_ports_unfiltered.txt"

echo "[*] Running httpx on final ips..."
cat "$FINAL_IPS" | httpx -silent -nc -threads 15 -rate-limit 30 -timeout 15 -sc -location -cl -ct -title -server -asn -ip -cdn -favicon -td -o "$HTTPX_IPS_DIR/httpx_final_ips_unfiltered.txt"
echo "[✔] httpx scan completed. Total $(wc -l < "$HTTPX_IPS_DIR/httpx_final_ips_unfiltered.txt") unfiltered lines."

echo "[*] Running httpx on ips_with_ports..."
cat "$IPS_WITH_PORTS" | httpx -silent -nc -threads 15 -rate-limit 30 -timeout 15 -sc -location -cl -ct -title -server -asn -ip -cdn -favicon -td -o "$HTTPX_IPS_DIR/httpx_ips_with_ports_unfiltered.txt"
echo "[✔] httpx scan completed. Total $(wc -l < "$HTTPX_IPS_DIR/httpx_ips_with_ports_unfiltered.txt") unfiltered lines."

# Merge and filter
cat $HTTPX_IPS_DIR/httpx_final_ips_unfiltered.txt $HTTPX_IPS_DIR/httpx_ips_with_ports_unfiltered.txt | sort -u > "$HTTPX_IPS_DIR/httpx_final_ips-ips_with_ports_unfiltered.txt"

# ips with http-https, plain ips
awk '{print $1}' "$HTTPX_IPS_DIR/httpx_final_ips-ips_with_ports_unfiltered.txt" > "$IPS_ORGANIZED_DIR/httpx_final_ips_with_http-https.txt"
echo "[✔] Created httpx_final_ips_with_http-https.txt with $(wc -l < "$IPS_ORGANIZED_DIR/httpx_final_ips_with_http-https.txt") lines."

sed -E 's~^https?://~~' "$IPS_ORGANIZED_DIR/httpx_final_ips_with_http-https.txt" > "$IPS_ORGANIZED_DIR/httpx_final_ips_plain.txt"
echo "[✔] Created httpx_final_ips_plain.txt with $(wc -l < "$IPS_ORGANIZED_DIR/httpx_final_ips_plain.txt") lines."

# Organize by status code (simple flat files like subdomains)
echo "[*] Organizing HTTPX IP output by Status Codes..."
awk '{gsub(/\[|\]/,""); code=$2; if(code ~ /^[0-9]{3}$/) print $1 >> "'"$IPS_ORGANIZED_DIR"'/all_"code".txt"}' \
  "$HTTPX_IPS_DIR/httpx_final_ips-ips_with_ports_unfiltered.txt"

for f in "$IPS_ORGANIZED_DIR"/all_*.txt; do
  [ -e "$f" ] || continue
  sort -u "$f" -o "$f"
  echo "[✔] Created $(basename "$f") with $(wc -l < "$f") lines"
done

# Organize by HTTP title
echo "[*] Organizing URLs by HTTP Title..."
while IFS= read -r rec || [ -n "$rec" ]; do
    URL="${rec%% *}"
    mapfile -t FIELDS < <(printf "%s\n" "$rec" | grep -o '\[[^]]*\]' | sed 's/^\[//; s/\]$//')
    TITLE="${FIELDS[4]:-}"
    EIGHTH="${FIELDS[6]:-}"
    if [[ "$EIGHTH" =~ ^AS[0-9]+$ || "$EIGHTH" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        SAFE_TITLE=$(printf "%s" "$TITLE" | sed 's#[/:*?"<>|&$!`'"'"' \t\r\n]#_#g')
        [ -z "$SAFE_TITLE" ] && SAFE_TITLE="EMPTY"
    else
        SAFE_TITLE="EMPTY"
    fi
    echo "$URL" >> "$IPS_ORGANIZED_DIR/http-title_urls/${SAFE_TITLE}.txt"
done < <(sed -E 's#[[:space:]]+(https?://)#\n\1#g' "$HTTPX_IPS_DIR/httpx_final_ips-ips_with_ports_unfiltered.txt" | sed '/^\s*$/d')

TITLE_FILES_COUNT=$(find "$IPS_ORGANIZED_DIR/http-title_urls" -type f -name '*.txt' | wc -l)
echo "[✔] Created $TITLE_FILES_COUNT title-based files in http-title_urls"
