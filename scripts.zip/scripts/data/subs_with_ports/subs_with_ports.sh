#!/bin/bash

if [ -z "$1" ]; then
    echo "Usage: $0 <company name>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
FINAL_SUBDOMAINS="$BASE_DIR/data/subdomains/final_subdomains.txt"
OUTPUT_FILE="$BASE_DIR/data/subs_with_ports/subs_with_ports.txt"

[ -s "$FINAL_SUBDOMAINS" ] || { echo "[✖] Missing or empty file: $FINAL_SUBDOMAINS"; exit 1; }

mkdir -p "$BASE_DIR/data/subs_with_ports"
> "$OUTPUT_FILE"

# Loop through each subdomain (supports multiple subdomains)
while read -r subdomain; do
    if [ -z "$subdomain" ]; then
        continue
    fi

    # Get IP via ping with 15-second timeout
    ip=$(ping -c 1 -W 15 "$subdomain" 2>/dev/null | grep 'PING' | awk -F'[()]' '{print $2}')

    if [ -n "$ip" ]; then
        echo "-> Processing $subdomain ($ip)"
        total_ports=0

        # Query Shodan InternetDB via Python for this IP
        ports=$(python3 - <<END
import json
import urllib.request

ip = "$ip"
try:
    url = f"https://internetdb.shodan.io/{ip}"
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as response:
        data = json.loads(response.read().decode())
        ports = data.get("ports", [])
        print(",".join(str(p) for p in ports))
except Exception as e:
    pass
END
)

        # Write subdomain:port to output file (skip 80 and 443)
        only_80443=true
        if [ -n "$ports" ]; then
            IFS=',' read -ra port_array <<< "$ports"
            declare -A seen=()
            for port in "${port_array[@]}"; do
                [[ -z "$port" ]] && continue
                [[ "$port" =~ ^[0-9]+$ ]] || continue
                if [[ "$port" -eq 80 || "$port" -eq 443 ]]; then
                    continue
                fi
                only_80443=false
                if [[ -z "${seen[$port]}" ]]; then
                    echo "$subdomain:$port" >> "$OUTPUT_FILE"
                    seen[$port]=1
                    total_ports=$((total_ports + 1))
                fi
            done
        fi

        # Informative message when only 80/443 (or no extra ports) were found
        if [ "$total_ports" -eq 0 ] && [ -n "$ports" ]; then
            echo "[!] Only 80/443 found for $subdomain – skipping"
        fi

        echo "$total_ports ports found for $subdomain"
    else
        echo "[!] $subdomain did not respond to ping within 15 seconds"
    fi

    # Delay between requests
    sleep 2

done < "$FINAL_SUBDOMAINS"

echo "[✔] Total $(wc -l < "$OUTPUT_FILE") subs_with_ports found."
