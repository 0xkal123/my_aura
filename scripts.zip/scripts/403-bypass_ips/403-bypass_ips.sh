#!/bin/bash

# =====================
# 🔹 INPUT VALIDATION
# =====================
if [ $# -ne 1 ]; then
    echo "Usage: $0 <company_name>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/${COMPANY}"
SUBDOMAINS_ORGANIZED_DIR="${BASE_DIR}/data/ips_organized"
BYP4XX_DIR="/root/Desktop/tools/byp4xx"

# =====================
# 🔹 4XX BYPASS
# =====================
echo "[*] Running 4XX bypass..."
mkdir -p "$BASE_DIR/403-bypass_ips"

# Loop through all merged all_<code>.txt files
for FILE in "$SUBDOMAINS_ORGANIZED_DIR"/all_*.txt; do
    [ -e "$FILE" ] || continue
    CODE=$(basename "$FILE" | cut -d'_' -f2 | cut -d'.' -f1)

    # Only run bypass for 4xx codes
    if [[ "$CODE" =~ ^4[0-9]{2}$ ]]; then
        echo "[*] Running bypass on $CODE status code URLs..."
        byp4xx --all -L "$FILE" > "$BASE_DIR/403-bypass_ips/all_${CODE}.txt"
        echo "[✔] Byp4xx results for $CODE saved to $BASE_DIR/403-bypass_ips/all_${CODE}.txt"
    fi
done

echo "[✓] 4XX bypass complete. Results saved in: $BASE_DIR/403-bypass_ips"


# =====================
# 🔹 FINISHED
# =====================
echo "[✓] 4xx bypasses check completed successfully."
