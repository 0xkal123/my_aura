#!/bin/bash

# Usage: ./origin.sh <company>
if [ $# -ne 1 ]; then
    echo "Usage: $0 <company>"
    exit 1
fi

COMPANY="$1"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY"
IPS_FILE="$BASE_DIR/data/ips/final_ips.txt"
SUBS_FILE="$BASE_DIR/data/subdomains_organized/httpx_final_subs_plain.txt"
OUTPUT_DIR="$BASE_DIR/origin_ips"
GENERAL_DIR="$OUTPUT_DIR/general"

mkdir -p "$GENERAL_DIR"

OUTPUT_IPS="$GENERAL_DIR/ORIGIN_IPs_200.txt"
OUTPUT_SUBS="$GENERAL_DIR/content-length_subs.txt"
OUTPUT_IPS_LEN="$GENERAL_DIR/content-length_ips.txt"
OUTPUT_SSL="$OUTPUT_DIR/ORIGIN_IPs_SSL.txt"
ALIGNED_OUTPUT="$OUTPUT_DIR/aligned_content_length.txt"

# Clear old files
> "$OUTPUT_IPS"
> "$OUTPUT_SUBS"
> "$OUTPUT_IPS_LEN"
> "$OUTPUT_SSL"
> "$ALIGNED_OUTPUT"

echo "[*] Checking IP origins and HTTP 200 status..."
while read -r ip; do
    [ -z "$ip" ] && continue
    echo "[•] Checking $ip"
    
    # Check ShodanIDB for Cloudflare
    response=$(curl -s -A "Mozilla/5.0" "https://internetdb.shodan.io/$ip" 2>/dev/null)
    
    if ! echo "$response" | grep -q -e 'cpe:/a:cloudflare:cloudflare' \
                             -e 'cpe:2.3:a:cloudflare:cloudflare' \
                             -e 'cpe:/a:amazon:amazon_cloudfront' \
                             -e 'cpe:2.3:a:amazon:amazon_cloudfront' \
                             -e 'cpe:/a:akamai:akamaighost' \
                             -e 'cpe:2.3:a:akamai:akamaighost' \
                             -e 'cpe:/o:f5:tmos' \
                             -e 'cpe:2.3:o:f5:tmos' \
                             -e 'cpe:/a:barracuda:network_access_client' \
                             -e 'cpe:2.3:a:barracuda:network_access_client' \
                             -e 'cpe:/a:cloudflare:load_balancing' \
                             -e 'cpe:2.3:a:cloudflare:load_balancing' \
                             -e 'cpe:/a:barracuda:web_filter' \
                             -e 'cpe:2.3:a:barracuda:web_filter' \
                             -e 'cpe:/a:f5:big-ip_fraud_protection_service' \
                             -e 'cpe:2.3:a:f5:big-ip_fraud_protection_service' \
                             -e 'cpe:/a:akamai:kona_site_defender_service' \
                             -e 'cpe:2.3:a:akamai:kona_site_defender_service'; then
        # Check if the origin IP responds with HTTP 200
        if echo "$ip" | httpx -silent -nc -threads 20 -rate-limit 25 -timeout 10 -mc 200 | grep -q '.'; then
            echo "  → Origin IP found: $ip"
            
            # Save IP to ORIGIN_IPs_200.txt
            echo "$ip" >> "$OUTPUT_IPS"

            # Save structured IP + cero output to ORIGIN_IPs_SSL.txt
            {
                echo "=> $ip"
                echo "$ip" | cero -c 5
                echo ""
            } >> "$OUTPUT_SSL"

        else
            echo "  → Origin IP but no HTTP 200"
        fi
    else
        echo "  → Cloudflare protected"
    fi
done < <(grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' "$IPS_FILE")

echo "[*] Extracting content-lengths with httpx..."
cat "$SUBS_FILE" | httpx -cl -silent -nc -threads 4 -rate-limit 5 -timeout 15 > "$OUTPUT_SUBS"
cat "$OUTPUT_IPS" | httpx -cl -silent -nc -threads 4 -rate-limit 5 -timeout 15 > "$OUTPUT_IPS_LEN"

# ================================
# Align subdomains with IPs by nearest Content-Length (>=70% similarity)
# ================================
echo "[*] Aligning subdomains with IPs by Content-Length..."

# Read subs into associative array
declare -A subs
while read -r url len; do
    len=$(echo "$len" | tr -d '[]')
    subs["$url"]=$len
done < "$OUTPUT_SUBS"

# Read IPs into associative array
declare -A ips
while read -r url len; do
    len=$(echo "$len" | tr -d '[]')
    ips["$url"]=$len
done < "$OUTPUT_IPS_LEN"

# Compare and align
for s in "${!subs[@]}"; do
    slen=${subs[$s]}
    best_ip=""
    best_diff=999999
    for i in "${!ips[@]}"; do
        ilen=${ips[$i]}
        slen=${slen:-0}
        ilen=${ilen:-0}

        diff=$(( slen > ilen ? slen - ilen : ilen - slen ))

        # Handle 0 content-length: if both are 0, treat as 100% match
        if [[ "$slen" -eq 0 && "$ilen" -eq 0 ]]; then
            percent=100
        elif [[ "$slen" -eq 0 ]]; then
            percent=0
        else
            percent=$(( 100 - (diff * 100 / slen) ))
        fi

        if (( percent >= 70 && diff < best_diff )); then
            best_diff=$diff
            best_ip=$i
        fi
    done
    if [[ -n $best_ip ]]; then
        printf "%-80s <--> %s\n" "$s [$slen]" "$best_ip [${ips[$best_ip]}]" >> "$ALIGNED_OUTPUT"
    fi
done

# sort descending by subdomain content-length
sort -k2,2nr -t'[' "$ALIGNED_OUTPUT" -o "$ALIGNED_OUTPUT"

echo "[✔] Done."
echo "HTTP 200 IPs saved to $OUTPUT_IPS"
echo "Content-lengths saved to $OUTPUT_SUBS and $OUTPUT_IPS_LEN"
echo "Aligned output saved to $ALIGNED_OUTPUT"
echo "IP + cero SSL output saved to $OUTPUT_SSL"
