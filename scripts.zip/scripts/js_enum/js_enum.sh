#!/bin/bash

# ================================
# Filtering 200 status code JS urls using js_enum
# ================================

if [ -z "$1" ]; then
  echo "Usage: ./js_enum.sh <company>"
  exit 1
fi

COMPANY=$1
FINAL_ALL_ARCHIVE="/root/Desktop/BB/recon/$COMPANY/data/archive_data_subs/final_all_archive.txt"
SCOPE_FILE="/root/Desktop/BB/recon/$COMPANY/scope_${COMPANY}.txt"
BASE_DIR="/root/Desktop/BB/recon/$COMPANY/js_enum"

# Ensure base directory exists
mkdir -p "$BASE_DIR"

# ================================
# Check required files and tools
# ================================
[ ! -f "$FINAL_ALL_ARCHIVE" ] && { echo "[✖] Final archive file not found: $FINAL_ALL_ARCHIVE"; exit 1; }
[ ! -f "$SCOPE_FILE" ] && { echo "[✖] Scope file not found: $SCOPE_FILE"; exit 1; }
command -v httpx >/dev/null 2>&1 || { echo "[✖] httpx not found"; exit 1; }
command -v gitleaks >/dev/null 2>&1 || { echo "[✖] gitleaks not found"; exit 1; }

# ================================
# Filtering js URLs from final archive
# ================================
echo "[▶] Filtering JS URLs from $FINAL_ALL_ARCHIVE ..."
grep -Ei '\.js($|\?)' "$FINAL_ALL_ARCHIVE" > "$BASE_DIR/js_urls.txt" || { echo "[✖] Failed to filter JS URLs"; exit 1; }
[ -s "$BASE_DIR/js_urls.txt" ] && echo "[✔] Filtered $(wc -l < "$BASE_DIR/js_urls.txt") JS URLs." || { echo "[✖] No JS URLs found."; exit 1; }

# ================================
# Filtering JS URLs based on scope
# ================================
grep -Ff "$SCOPE_FILE" "$BASE_DIR/js_urls.txt" > "$BASE_DIR/js_urls_in_scope.txt"
[ ! -s "$BASE_DIR/js_urls_in_scope.txt" ] && { echo "[✖] No JS URLs matched the scope. Exiting."; exit 1; }
echo "[✔] $(wc -l < "$BASE_DIR/js_urls_in_scope.txt") in-scope JS URLs saved to $BASE_DIR/js_urls_in_scope.txt"

# ================================
# Filtering only valid JS urls
# ================================
echo "[▶] Running httpx on $BASE_DIR/js_urls_in_scope.txt ..."
httpx -silent -nc -threads 25 -timeout 10 -mc 200 -ct \
  -l "$BASE_DIR/js_urls_in_scope.txt" \
  -o "$BASE_DIR/httpx_raw.txt"

grep -E "application/javascript|application/x-javascript|application/ecmascript|application/x-ecmascript|application/json|application/x-json|application/octet-stream|text/javascript|text/x-javascript|text/ecmascript|text/x-ecmascript|text/plain|text/plain|x-text/plain|text/javascript|x-text/javascript" \
  "$BASE_DIR/httpx_raw.txt" | awk '{print $1}' > "$BASE_DIR/js_urls_working.txt"

[ -s "$BASE_DIR/js_urls_working.txt" ] && echo "[✔] $(wc -l < "$BASE_DIR/js_urls_working.txt") working JS URLs found." || { echo "[✖] No working JS URLs found. Exiting."; exit 1; }

# ================================
# Step 4: Process JS URLs
# ================================
while read -r url; do
  [ -z "$url" ] && continue
  host=$(echo "$url" | awk -F/ '{print $3}')
  TARGET_DIR="$BASE_DIR/$host"
  mkdir -p "$TARGET_DIR"

  # Classify main/app JS URLs
  echo "$url" | grep -E '(main|app)(\.[A-Za-z0-9]+){0,10}\.js' >> "$TARGET_DIR/main-app_js_urls.txt"
  echo "$url" | grep -vE '(main|app)(\.[A-Za-z0-9]+){0,10}\.js' >> "$TARGET_DIR/other_than_main-app_js_urls.txt"

  # One curl per URL → save file for LinkFinder + Gitleaks
  TMP_JS="$(mktemp)" || { echo "[✖] Failed to create temp file"; exit 1; }
  TMP_JS_PRETTY="$(mktemp)" || { echo "[✖] Failed to create temp file"; exit 1; }
  curl -skL "$url" -o "$TMP_JS" || { echo "[✖] Failed to download $url"; continue; }

  # Beautify JS if possible
  if command -v js-beautify >/dev/null 2>&1; then
    js-beautify -f "$TMP_JS" -o "$TMP_JS_PRETTY" >/dev/null 2>&1 || cp "$TMP_JS" "$TMP_JS_PRETTY"
  elif command -v prettier >/dev/null 2>&1; then
    prettier --parser babel "$TMP_JS" > "$TMP_JS_PRETTY" 2>/dev/null || cp "$TMP_JS" "$TMP_JS_PRETTY"
  else
    cp "$TMP_JS" "$TMP_JS_PRETTY"
  fi

  # Keyword highlighting
TERMS=(
  "link" "key" "token"
  "secret" "app_id" "config" "connectionstring"
  "ssh:" "auth" "password" "passwd" "pwd" "pasword"
  "://"
  "id:" "id=" "id :" "id =" "'id'" "id\""
  "url:" "url=" "url :" "url =" "'url'" "url\""
  "api:" "api=" "api :" "api =" "'api'" "api\""
  "login:" "login=" "login :" "login =" "'login'" "login\""
  "user:" "user=" "user :" "user =" "'user'" "user\""
  "host:" "host=" "host :" "host =" "'host'" "host\""
  "REGION=" "REGION =" "REGION :" "REGION:" "'REGION'" "REGION\""
  "client:" "client :" "client=" "client =" "'client'" "client\""
  "smtp"
  "sql"
  "credentials" "server" "username" "dbuser"
  "aws" "azure" "gcp"
  "admin" "gsecr" "sandbox" "private" "bearer" "jdbc" "amazon" "amzn"
  "pgp" "rsa" "AKIA" "A3T" "AGPA" "AIDA" "AROA" "AIPA" "ANPA" "ANVA" "ASIA" "AIZA"
  ".mws" "s3." "aes" "hmac" "gcm" "privatekey" "publickey"
  "firebase" ".appspot" "jwt" "jwk" "pem" "p12" "ppk" "ovpn" "bucket"
  "MAIL_PORT" "MAIL_HOST" "MEMCACHED_HOST"
  "DB_HOST" "DB_PORT" "DB_DATABASE"
  "connection" "azurestorage" "BlobStorageConnection" "CloudStorageConnection"
)

  COLORS=(
    '\033[1;31m' '\033[1;32m' '\033[1;33m' '\033[1;34m'
    '\033[1;35m' '\033[1;36m' '\033[0;91m' '\033[0;92m'
    '\033[0;93m' '\033[0;94m' '\033[0;95m' '\033[0;96m'
  )
  NC='\033[0m'

  KW_OUT="$TARGET_DIR/keyword_hits.txt"
  {
    echo "## JS URL: $url"
    for i in "${!TERMS[@]}"; do
      t="${TERMS[$i]}"
      color="${COLORS[$((i % ${#COLORS[@]}))]}"
      matches="$(grep -n -i -- "$t" "$TMP_JS_PRETTY" || true)"
      [ -n "$matches" ] && { echo -e "-> Term: ${color}${t}${NC}"; echo -e "${matches//$t/${color}$t${NC}}"; echo; }
    done
    echo
  } >> "$KW_OUT"

  # Run gitleaks → per-URL JSON block
  {
    echo "## JS URL: $url"
    gitleaks detect --no-banner --no-git --source "$TMP_JS" \
       -c "/root/Desktop/tools/secrets-patterns-db/gitleaks.toml" \
       --report-format json --report-path /dev/stdout \
    | jq '[.[] | {Description, Match, Secret}]' || echo "[!] gitleaks failed for $url"
    echo ""
  } >> "$TARGET_DIR/common-regex-secrets.json"

  rm -f "$TMP_JS" "$TMP_JS_PRETTY"

done < "$BASE_DIR/js_urls_working.txt"

# Group third-party URLs
[ -f "$BASE_DIR/urls_of_third-party.txt" ] && \
  sort -t/ -k3,3 "$BASE_DIR/urls_of_third-party.txt" -o "$BASE_DIR/urls_of_third-party.txt"

echo "[+] JS enumeration completed for $COMPANY"
